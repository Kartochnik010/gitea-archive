package main

import (
	"fmt"
	"os"
	"reflect"
)

// ".96.4...1" "1...6...4" "5.481.39." "..795..43" ".3..8...." "4.5.23.18" ".1.63..59" ".59.7.83." "..359...7"

func main() {
	args := []string(os.Args[1:]) // os.Args arguments go run main.go "My" "".3..8...." "is" "beatiful" os.Args[1] = "My" (os.Args = []string (["My" "".3..8...." "is" "beatiful"]) )

	if !ValidInput(args) {
		fmt.Println("Error")
		return
	}

	s := make([][]int, 9) // [0 0 0 0 0 0 0 0]
	for i := range s {
		s[i] = make([]int, 9) //  [[0 0 0 0 0 0 0 0], [0 0 0 0 0 0 0 0], [0 0 0 0 0 0 0 0], [0 0 0 0 0 0 0 0]]
	}
	// args = ".96.4...1" ".96.4...1",
	//  s = [[0],[0],[0],[0],[0],[]0]
	ParseData(args, s)

	// s = [[1, 0 2]. [2, 0,0 ]]
	doubleCheck := s
	if !BoardValid(s) { // !false = true
		fmt.Println("Error")
	} else {
		SudokuSolve(s)
		SudokuSolve(doubleCheck)
		if reflect.DeepEqual(s, doubleCheck) {
			for j := 0; j < len(s); j++ {
				PrintRow(s[j])
			}
		} else {
			fmt.Println("Error")
		}
	}
}

func ValidInput(args []string) bool {
	if len(args) != 9 {
		return false
	}

	for i := 0; i < len(args); i++ {
		if len(args[i]) != 9 {
			return false
		}
	}
	return true
}

func PrintRow(s []int) {
	for i := 0; i < len(s)-1; i++ {
		fmt.Printf("%v", s[i])
		fmt.Printf(" ")
	}
	fmt.Printf("%v", s[len(s)-1])
	fmt.Printf("\n")
}

func ParseData(args []string, s [][]int) {
	for i := 0; i < len(args); i++ {
		for j := 0; j < len(args); j++ {
			if []rune(args[i])[j] > 48 && []rune(args[i])[j] < 58 { // 48 = '0' , 57 = '9'
				s[i][j] = int(rune(args[i][j]) - 48)
			} else {
				s[i][j] = int(0) // s[0][0] = 0
			}
		}
	}
}

// ".96.4...1" > [0 9 6 0 4 0 0 0 1]

// []rune(args[0])[0] > 48 = []rune

func SudokuSolve(board [][]int) bool {
	if !Empty(board) {
		return true
	}

	for i := 0; i < 9; i++ {
		for j := 0; j < 9; j++ {
			if board[i][j] == 0 {
				for guess := 9; guess >= 1; guess-- {
					board[i][j] = guess
					if BoardValid(board) {
						if SudokuSolve(board) {
							return true
						}
						board[i][j] = 0
					} else {
						board[i][j] = 0
					}
				}
				return false
			}
		}
	}
	return false
}

func Empty(board [][]int) bool {
	for i := 0; i < 9; i++ {
		for j := 0; j < 9; j++ {
			if board[i][j] == 0 {
				return true
			}
		}
	}
	return false
}

func BoardValid(board [][]int) bool {
	// horizontal check
	for row := 0; row < 9; row++ {

		cnt := [10]int{} // {0 ; 1 ; 1 ; 1 ; 1 ; 1 ; 1 ; 1 ; 1; 1}
		for col := 0; col < 9; col++ {
			cnt[board[row][col]]++ // cnt[board[0][0]] // cnt[7] // ++ // {0 ; 0 ; 0 ; 0 ; 0 ; 0 ; 0 ; 1 ; 0 ; 0}
		}
		if HasCopy(cnt) {
			return false
		}

	}
	// vertical check
	for row := 0; row < 9; row++ {
		cnt := [10]int{}
		for col := 0; col < 9; col++ {
			cnt[board[col][row]]++
		}
		if HasCopy(cnt) {
			return false
		}
	}

	// box check
	for i := 0; i < 9; i += 3 {
		for j := 0; j < 9; j += 3 {

			cnt := [10]int{} // {0 ; 0 ; 0 ; 0 ; 0 ; 0 ; 0 ; 0 ; 0 ; 0}

			for row := i; row < i+3; row++ {
				for col := j; col < j+3; col++ {
					cnt[board[row][col]]++
				}
				if HasCopy(cnt) {
					return false
				}
			}

		}
	}
	return true
}

func HasCopy(cnt [10]int) bool {
	for i, v := range cnt {
		if i == 0 {
			continue
		}
		if v > 1 {
			return true
		}
	}
	return false
}
