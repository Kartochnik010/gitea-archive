package controllers

import (
	"groupie-tracker/model"
	"log"
	"net/http"
	"strings"
	"text/template"
)

func Home(w http.ResponseWriter, r *http.Request) {
	tmpl := template.Must(template.ParseFiles("./static/templates/home.html"))
	var artists []model.Artist
	artists, err := GetArtists()
	if err != nil {
		log.Fatal(err)
	}
	data := &model.MainInfo{
		Artists: artists,
	}
	tmpl.Execute(w, data)
}

func Artist(w http.ResponseWriter, r *http.Request) {
	tmpl := template.Must(template.ParseFiles("./static/templates/artist.html"))
	query := r.URL.Path

	id := parseIdFromPath(query)

	artist, err := GetArtist(id)
	if err != nil {
		log.Fatal(err)
	}

	tmpl.Execute(w, artist)
}

func parseIdFromPath(s string) string {
	raw := strings.Split(s, "/")
	return raw[len(raw)-1]
}
