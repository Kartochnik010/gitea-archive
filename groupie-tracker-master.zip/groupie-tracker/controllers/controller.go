package controllers

import (
	"encoding/json"
	"errors"
	"groupie-tracker/model"
	"io/ioutil"
	"net/http"
)

const (
	ArtistApiUrl   string = "https://groupietrackers.herokuapp.com/api/artists"
	RelationApiUrl string = "https://groupietrackers.herokuapp.com/api/relation"
	LocationApiUrl string = "https://groupietrackers.herokuapp.com/api/locations"
)

func GetArtists() ([]model.Artist, error) {
	req, err := http.Get(ArtistApiUrl)
	var artists []model.Artist
	if err != nil {
		return artists, err
	}
	body, err := ioutil.ReadAll(req.Body)
	if err != nil {
		return artists, err
	}
	err = json.Unmarshal(body, &artists)
	if err != nil {
		return artists, errors.New("JSON error")
	}
	return artists, nil
}

func GetArtist(id string) (model.Artist, error) {
	req, err := http.Get(ArtistApiUrl + "/" + id)
	var artist model.Artist
	if err != nil {
		return artist, err
	}
	body, err := ioutil.ReadAll(req.Body)
	if err != nil {
		return artist, err
	}
	err = json.Unmarshal(body, &artist)

	if err != nil {
		return artist, errors.New("JSON error")
	}
	return artist, nil
}
