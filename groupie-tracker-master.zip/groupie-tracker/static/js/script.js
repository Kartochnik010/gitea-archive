// let items = document.querySelectorAll(".my-list-item")


// for (let i = 0; i < items.length; i++) {
//     const e = items[i];
//     console.log(e);

//         e.addEventListener("click", ()=> {
//             e.classList.toggle("done")
//         })
    
// }

// items.forEach(e => {
//     e.addEventListener("click", ()=> {
//         e.classlist.toggle("done")
//     })
// });