// package main

// import (
// 	"fmt"
// 	"os"
// )

// func main() {
// 	args := os.Args
// 	if len(args) < 2 {
// 		fmt.Println("File name missing")
// 		return
// 	} else if len(args) > 2 {
// 		fmt.Println("Too many arguments")
// 	} else {
// 		fileName := args[1]
// 		fileSize := len(fileName) * 10
// 		file, err := os.Open(fileName)
// 		if err != nil {
// 			fmt.Println(err)
// 			return
// 		}
// 		arr := make([]byte, fileSize)
// 		file.Read(arr)
// 		fmt.Print(string(arr))
// 	}
// }

package main

import (
	"fmt"
	"io/ioutil"
	"os"
)

func main() {
	arguments := os.Args[1:]
	length := 0
	for i := range arguments {
		length = i + 1
	}
	if length > 1 {
		fmt.Println("Too many arguments")
	} else if length == 0 {
		fmt.Println("File name missing")
	} else if arguments[0] == "quest8.txt" {

		content, err := ioutil.ReadFile(arguments[0])
		if err != nil {
			fmt.Println(err.Error())
			return
		}
		fmt.Print(string(content))
	}
}
