ls - check packages


mkdir - creates directory


cd - go to directory


cd ../ - exit current directory


code main.go- creates the root file





go mod init piscine - creates module for piscine


go mod tidy - pulls to cache if not already there

you see a schedule to respect
engage as much people as you can, bigger perspective does matter
totally impossible to succeed by yourself

tr - CHANGES SYMBOLS TO OTHER SYMBOLS
$ echo 'Oh, hi, Mark!' | tr O o
oh, hi, Mark!


touch FILE_NAME -creates a file from console

CODE > FILE_NAME - inserts code in the file
$ echo echo R > r
$ . r
R

grep WHATEVER_YOU_WANNA_FIND DIRECTORY 
$ grep echo *
r:echo R

chmod 755 FILE_NAME - YOU CAN TRY CHANGING THE PERMISSIONS IF FILE WON'T RUN

STRING | sed 's/ (REPLACE WHAT) / (REPLACE WITH THIS) / (PUT g HERE IF YOU WANNA MAKE IT AFFECT WHOLE STRING)'
$ echo Hey bro looking mighty fine today! | sed 's/o/O/g'
Hey brO lOOking mighty fine tOday!
$ echo Hey bro looking mighty fine today! | sed 's/ /AH/'
HeyAHbro looking mighty fine today!

find . -name 'a*' -LOOKS FOR FILES IN CURRENT DIRECTORY THAT STARTS WITH 'a'
find . -name '*a' -LOOKS FOR FILES IN CURRENT DIRECTORY THAT ENDS WITH 'a'
find . -name '*a*' -LOOKS FOR FILES IN CURRENT DIRECTORY THAT HAS 'a' IN IT
find . -name 'a*' -and -name '*b' -LOOKS FOR FILES IN CURRENT DIRECTORY THAT STARTS WITH 'a' AND ENDS WITH 'b'

$ curl "https://api.github.com/users" - returns a JSON
$ curl "https://api.github.com/users" | jq '.' - returns beautiful JSON
$ curl "https://api.github.com/users" | jq '.[]' - return JSON, but breaks one brakets, like [{},{},{}], so it gives you, {},{},{}
$ curl "https://api.github.com/users" | jq '.[] .login' - returns logins of all
$ curl "https://api.github.com/users" | jq '.[] | select(.id == 45) | .login' - returns login of a specific user with id 45(cool right?)

how to mutate string:

func StrRev(s string) string {
	drow := s
	drowReversable := []rune(drow)
	for i, v := range s {
		drowReversable[len(s)-i-1] = v
	}
	drowReversed := string(drowReversable)
	return drowReversed
}

0 : 0
1 : 1
2 : 2
3 : 3
4 : 4
5 : 5
6 : 6
7 : 7
8 : 8
9 : 9
: : 10
; : 11
< : 12
= : 13
> : 14
? : 15
@ : 16
A : 17
B : 18
C : 19
D : 20
E : 21
F : 22
G : 23
H : 24
I : 25
J : 26
K : 27
L : 28
M : 29
N : 30
O : 31
P : 32
Q : 33
R : 34
S : 35
T : 36
U : 37
V : 38
W : 39
X : 40
Y : 41
Z : 42
[ : 43
\ : 44
] : 45
^ : 46
_ : 47
` : 48
a : 49
b : 50
c : 51
d : 52
e : 53
f : 54
g : 55
h : 56
i : 57
j : 58
k : 59
l : 60
m : 61
n : 62
o : 63
p : 64
q : 65
r : 66
s : 67
t : 68
u : 69
v : 70
w : 71
x : 72
y : 73
z : 74
{ : 75
| : 76
} : 77
~ : 78