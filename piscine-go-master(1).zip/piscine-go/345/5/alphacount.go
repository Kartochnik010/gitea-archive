package piscine

func AlphaCount(s string) int {
	runes := []rune(s)
	cnt := 0
	for i := 0; i < len(s); i++ {
		if runes[i] >= 'a' && runes[i] <= 'z' {
			cnt++
		}
	}
	for i := 0; i < len(s); i++ {
		if int(runes[i]) >= 'A' && int(runes[i]) <= 'Z' {
			cnt++
		}
	}

	return cnt
}
