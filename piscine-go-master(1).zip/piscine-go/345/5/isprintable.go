package piscine

func IsPrintable(s string) bool {
	runes := []rune(s)

	for i := range runes {
		if runes[i] >= 0 && runes[i] <= 31 {
			return false
		}
	}
	return true
}
