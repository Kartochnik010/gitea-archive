package piscine

func BasicJoin(strs []string) string {
	var res string
	for i := range strs {
		res += strs[i]
	}

	return res
}
