package piscine

func NRune(s string, n int) rune {
	allRunes := []rune(s)
	if len(s) < n || n <= 0 {
		return 0
	}
	n = n - 1

	return allRunes[n]
}
