package piscine

func LastRune(s string) rune {
	allRunes := []rune(s)
	return allRunes[len(s)-1]
}
