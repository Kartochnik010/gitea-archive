package piscine

func FirstRune(s string) rune {
	allRunes := []rune(s)
	return allRunes[0]
}
