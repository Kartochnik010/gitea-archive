package piscine

func Index(s string, toFind string) int {
	a := []rune(s)
	b := []rune(toFind)

	var match bool
	if len(a) == 0 || len(b) > len(a) {
		return -1
	}
	if len(b) == 0 {
		return 0
	}

	for i := 0; i < len(a)-len(b); i++ {
		if a[i] == b[0] {
			match = true
			for j := 0; j < len(b)-1; j++ {
				if a[i+j] != b[j] {
					match = false
				}
			}
			if match {
				return i
			}
		}
	}
	return -1
}
