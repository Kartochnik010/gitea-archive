package piscine

func ToLower(s string) string {
	runes := []rune(s)
	for i := 0; i < len(s); i++ {
		if runes[i] > 64 && runes[i] < 91 {
			runes[i] += 32
		}
	}
	return string(runes)
}
