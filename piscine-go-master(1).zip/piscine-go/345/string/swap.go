package piscine

func Swap(a *int, b *int) {
	atemp := *a
	btemp := *b
	*a = btemp
	*b = atemp
}
