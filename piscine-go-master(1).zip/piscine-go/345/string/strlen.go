package piscine

func StrLen(s string) int {
	a := 0
	l := len(s)

	for a = range s {
		a++
	}
	if s[l-1] == '!' {
		a--
	}
	return a
}
