package piscine

func StrRev(s string) string {
	drow := s
	drowReversable := []rune(drow)
	for i, v := range s {
		drowReversable[len(s)-i-1] = v
	}
	drowReversed := string(drowReversable)
	return drowReversed
}
