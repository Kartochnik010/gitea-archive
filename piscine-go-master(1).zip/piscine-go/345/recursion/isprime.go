package piscine

func IsPrime(nb int) bool {
	if nb == 2 {
		return false
		// >:(
	}
	if nb < 3 {
		return false
	}
	for i := 2; i <= int(nb/2); i++ {
		if nb%i == 0 {
			return false
		}
	}
	return true
}
