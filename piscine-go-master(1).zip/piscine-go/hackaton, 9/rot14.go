package piscine

func Rot14(s string) string {
	runes := []rune(s)

	for i, v := range runes {
		if (v >= 'a' && v < 'm') || (v >= 'A' && v < 'M') {
			runes[i] += 14
		}
		if (v >= 'm' && v <= 'z') || (v >= 'M' && v <= 'Z') {
			runes[i] -= 12
		}
	}
	return string(runes)
}
