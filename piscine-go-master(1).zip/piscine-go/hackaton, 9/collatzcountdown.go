package piscine

func CollatzCountdown(start int) int {
	if start <= 0 {
		return -1
	}
	if start == 1 {
		return 1
	}
	// For instance, starting with n = 12 and applying the function
	// f without "shortcut", one gets the sequence
	// 12, 6, 3, 10, 5, 16, 8, 4, 2, 1.
	cnt := 0
	for ; start != 1; cnt++ {
		if start%2 == 0 {
			start /= 2
		} else {
			start = 3*start + 1
		}
	}
	return cnt
}
