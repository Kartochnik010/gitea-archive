package piscine

func Join(strs []string, j string) string {
	var res string

	for i := 0; i < len(strs); i++ {
		if i != len(strs)-1 {
			res += strs[i] + j
		} else {
			res += strs[i]
		}
	}

	return res
}
