package piscine

func Compact(ptr *[]string) int {
	ss := *ptr
	cnt := 0

	for i := 0; i < len(ss); i++ {
		if ss[i] != "" {
			ss[cnt] = ss[i]
			cnt++
		}
	}
	*ptr = ss[0:cnt]
	return cnt
}
