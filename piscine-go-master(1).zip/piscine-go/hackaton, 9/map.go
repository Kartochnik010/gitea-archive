package piscine

func Map(f func(int) bool, a []int) []bool {
	bools := make([]bool, len(a))
	for i, v := range a {
		if f(v) {
			bools[i] = true
		} else {
			bools[i] = false
		}
	}
	return bools
}
