package piscine

func AppendRange(min, max int) []int {
	var a []int
	if min >= max {
		return a
	}

	// a := make([]int, max-min)

	for i := 0; i < max-min; i++ {
		a = append(a, i+min)
	}

	return a
}
