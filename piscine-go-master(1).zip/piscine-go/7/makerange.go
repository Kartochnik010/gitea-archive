package piscine

func MakeRange(min, max int) []int {
	var b []int
	if min >= max {
		return b
	}

	a := make([]int, max-min)

	for i := 0; i < max-min; i++ {
		a[i] = i + min
	}

	return a
}
