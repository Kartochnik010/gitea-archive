package piscine

func ConcatParams(args []string) string {
	var cum string
	for i := 0; i < len(args); i++ {
		cum += args[i]
		if !(i == len(args)-1) {
			cum += "\n"
		}
	}

	return cum
}
