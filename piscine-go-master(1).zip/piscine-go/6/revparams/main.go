package main

import (
	"os"

	"github.com/01-edu/z01"
)

func main() {
	arguments := os.Args
	for v := len(arguments) - 1; v >= 1; v-- {
		runes := []rune(arguments[v])
		for i := range arguments[v] {
			z01.PrintRune(runes[i])
		}
		z01.PrintRune('\n')
	}
}
