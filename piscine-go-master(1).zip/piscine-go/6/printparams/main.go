package main

import (
	"os"

	"github.com/01-edu/z01"
)

func main() {
	arguments := os.Args
	for v := 1; v < len(arguments); v++ {
		runes := []rune(arguments[v])
		for i := range arguments[v] {
			z01.PrintRune(runes[i])
		}
		z01.PrintRune('\n')
	}
}
