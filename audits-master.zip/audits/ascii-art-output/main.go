package main

import (
	"ascii-art-output/utils"
	"crypto/sha256"
	"fmt"
	"io"
	"log"
	"os"
)

func main() {
	a := os.Args[1:]

	if len(a) != 3 {
		fmt.Println("Usage: go run . [STRING] [BANNER] [OPTION]\nEX: go run . something standard --output=<fileName.txt>")
		return
	}

	s := string(a[1])
	if s == "standard" || s == "shadow" || s == "thinkertoy" {
		s += ".txt"
	}

	if s != "standard.txt" && s != "shadow.txt" && s != "thinkertoy.txt" { // checking if the user's banner name is correct(one of the three available)
		fmt.Println("Usage: go run . [STRING] [BANNER] [OPTION]\nEX: go run . something standard --output=<fileName.txt>")
		return
	}

	if !utils.ValidOutput(a[2]) {
		fmt.Println("Not valid filename for output!!!")
		return
	}

	if !openFiles256(s) { // calling function which checks if needed txt file is correct
		fmt.Printf("Expected Error: File %s corrupted\n", s)
		return
	}

	if len(a[0]) == 0 { // prints new line if given string is empty
		fmt.Println()
		return
	}

	outputFile := a[2][9:]
	if outputFile == "standard.txt" || outputFile == "shadow.txt" || outputFile == "thinkertoy.txt" {
		fmt.Println("Expected error: You cannot use the filenames of styles, please use another naming")
		return
	}

	f, err := os.Create(outputFile)
	if err != nil {
		log.Fatal(err)
	}

	defer f.Close()
	utils.PrintArt(utils.AscciiInt(a[0]), s, outputFile) // AsciiInt(s string) saves bytes into int array with respected Ascii numbers, an then PrintArt prints needed string
}

func openFiles256(s string) bool { // checking if needed txt file is not corrupted
	// correct txt files' coding
	hash_std := []byte{225, 148, 241, 3, 52, 66, 97, 122, 184, 167, 142, 28, 166, 58, 32, 97, 245, 204, 7, 163, 240, 90, 194, 38, 237, 50, 235, 157, 253, 34, 166, 191}
	hash_tky := []byte{243, 125, 219, 114, 118, 66, 122, 15, 188, 217, 227, 105, 214, 89, 103, 10, 252, 146, 207, 178, 243, 230, 71, 217, 19, 204, 220, 6, 169, 152, 222, 67}
	hash_shd := []byte{38, 185, 77, 11, 19, 75, 119, 233, 253, 35, 224, 54, 11, 253, 129, 116, 15, 128, 251, 127, 101, 65, 209, 216, 197, 216, 94, 115, 238, 85, 15, 115}

	f, err := os.Open(s)
	if err != nil {
		fmt.Println("Expected Error:\n", err)
	}
	defer f.Close()

	txt := sha256.New()
	if _, err := io.Copy(txt, f); err != nil {
		log.Fatal(err)
	}

	var hash []byte

	// checking if needed txt file is the correct one
	if s == "standard.txt" {
		hash = hash_std
	} else if s == "shadow.txt" {
		hash = hash_shd
	} else if s == "thinkertoy.txt" {
		hash = hash_tky
	}

	if string(txt.Sum(nil)) == string(hash) {
		return true
	} else {
		return false
	}
}
