# ASCII ART WEB #


to initialize project:

~go run cmd/main.go

or

~go run cmd/*

Purpose of project:


###### is a program which consists in receiving a string as an argument in text area and outputting the string in a graphic representation using ASCII.The result of program will be in html form. ######


**allowed range of ASCII is :** 32-126 (all alpa-numeric symbols in latin alphabet + additional common signs).



The project was written by ***Asya(m.a_k)*** and ***Aray(araya)*** 

students of ***Alem school***, 6-flow students	:grinning: