package app

import (
	"log"
	"net/http"
	"path/filepath"

	"ascii-art-web/internal/handlers"
)

const (
	port = ":8080"
)

type neuteredFileSystem struct {
	fs http.FileSystem
}

// Checks file path to internal file's
func (nfs neuteredFileSystem) Open(path string) (http.File, error) {
	f, err := nfs.fs.Open(path)
	if err != nil {
		return nil, err
	}
	s, err := f.Stat()
	if err != nil {
		log.Fatalf("Problem during getting file stat: %v", err.Error())
	}
	if s.IsDir() {
		index := filepath.Join(path, "./ui/html/home.html")
		if _, err := nfs.fs.Open(index); err != nil {
			closeErr := f.Close()
			if closeErr != nil {
				return nil, closeErr
			}
			return nil, err
		}
	}
	return f, nil
}

func App() error {
	mux := http.NewServeMux()
	mux.HandleFunc("/", handlers.GETHandler)
	mux.HandleFunc("/ascii-art", handlers.POSTHandler)
	fileServer := http.FileServer(neuteredFileSystem{http.Dir("./ui/static/")})
	mux.Handle("/static", http.NotFoundHandler())
	mux.Handle("/static/", http.StripPrefix("/static", fileServer))
	log.Println("Starting server on :8080")
	err := http.ListenAndServe(port, mux)
	return err
}
