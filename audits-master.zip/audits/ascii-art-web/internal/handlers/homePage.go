package handlers

import (
	"html/template"
	"log"
	"net/http"
	"strings"

	"ascii-art-web/internal/ascii"
)

type Ascii struct {
	AsciiFont string
}

var files = []string{
	"./ui/html/home.html",
}

func GETHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		http.Error(w, "ERROR-404\nPage not found", http.StatusNotFound)
		w.WriteHeader(http.StatusNotFound)
		return
	}
	if r.URL.Path != "/" {
		http.Error(w, "ERROR-404\nPage not found", http.StatusNotFound)
		return
	}
	html, err := template.ParseFiles(files...)
	if err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		log.Println(err.Error())
		http.Error(w, "Internal Server Error", http.StatusInternalServerError)
		return
	}
	err = html.Execute(w, nil)
	if err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		log.Println(err.Error())
		http.Error(w, "Internal Server Error", http.StatusInternalServerError)
	}
}

func POSTHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		http.Error(w, "Bad Request", http.StatusBadRequest)
		return
	}
	text := r.FormValue("formtext") // receives text to format
	font := r.FormValue("fonts")    // receives font's name
	text1 := ""
	// check if press enter for a new line
	for _, v := range text {
		if v == 10 || v == 13 { // checking if it's new line or '\r' (carriage ret)
			continue
		}
		if v < 32 || v > 126 { // if text is cyrrilic
			http.Error(w, "Bad Request", http.StatusBadRequest)
			return
		}
	}
	if strings.Contains(text, "\r\n") { // if text contains
		text1 = strings.ReplaceAll(text, "\r\n", "\n") // replace it with newline
	} else {
		text1 = text
	}
	if text1 == "" {
		http.Error(w, "Bad Request", http.StatusBadRequest)
		return
	}
	switch font {
	case "":
		font = "standard.txt"
	case "Standard":
		font = "standard.txt"
	case "Shadow":
		font = "shadow.txt"
	case "Thinkertoy":
		font = "thinkertoy.txt"
	default:
		w.WriteHeader(http.StatusBadRequest)
		http.Error(w, "Bad Request", http.StatusBadRequest)
		return
	}
	if !ascii.ConvertFont(font) {
		http.Error(w, "Internal Server Error", http.StatusInternalServerError)
		return
	}
	if ascii.HashSum(font) { // Checks font's files
		http.Error(w, "Bad Request", http.StatusBadRequest)
		return
	}
	// Converting ascii print and saves it in string
	result := ascii.OutputAscii(text1, font)

	ascii := Ascii{
		AsciiFont: result,
	}
	html, err := template.ParseFiles(files...)
	if err != nil {
		log.Println(err.Error())
		http.Error(w, "Internal Server Error", http.StatusInternalServerError)
		return
	}
	err = html.Execute(w, ascii)
	if err != nil {
		log.Println(err.Error())
		http.Error(w, "Internal Server Error", http.StatusInternalServerError)
	}
}
