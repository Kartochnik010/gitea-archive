package main

import (
	"log"

	server "ascii-art-web/internal/app"
)

func main() {
	err := server.App()
	if err != nil {
		log.Fatalln(err)
	}
}
