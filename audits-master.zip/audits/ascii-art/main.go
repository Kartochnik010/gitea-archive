package main

import (
	"errors"
	"fmt"
	"log"
	"os"
	"os/exec"
	"strconv"
	"strings"
)

func main() {
	var slice [][]string
	arr := [1]string{"n"}
	temp, err := os.ReadFile("standard.txt")
	if len(temp) != 6623 {
		fmt.Println("error with strandart file")
		return
	}
	if err != nil {
		log.Fatal("file not found \n", err)
	}

	x, err := Width()
	if err != nil {
		return
	}
	fmt.Println(x)
	template := strings.Split(string(temp), "\n\n")
	words, err := getData()
	if err != nil {
		fmt.Println(err)
	}

	num := 0
	for j := 0; j < len(words); j++ {
		for i := 0; i < len(words[j]); i++ {
			slice = append(slice, str(template[words[j][i]-32]))
			if slice[i][0] != "n" {
				num += len(slice[i][5])
			}
			if i != len(words[j])-1 {
				if int(x)-num < len(str(template[words[j][i+1]-32]))+10 {
					slice = append(slice, arr[:])
					num = 0
				}
			}
		}
		slice = append(slice, arr[:])
		num = 0
	}
	findNewLine(slice)
}

func getData() ([]string, error) {
	if len(os.Args[1:]) != 1 {
		return nil, errors.New("error: incorrect number of arguments given")
	}

	arg := os.Args[1]
	if arg == "" {
		fmt.Print()
		return nil, nil
	}
	var str string
	var arr []string
	if len(arg) < 1 {
		return nil, errors.New("")
	}

	str = strings.ReplaceAll(arg, "\\n", "\n")

	runes := []rune(arg)
	for i := 0; i < len(runes); i++ {
		if (runes[i] > 127 || runes[i] < 32) && runes[i] != 10 {
			return nil, errors.New("error don't use invalid symbol")
		}
	}

	arr = strings.Split(str, "\n")

	count := 0
	for i := 0; i < len(arr); i++ {
		if (arr[i]) == "" {
			count++
		}
	}

	if count == len(arr) {
		slice := arr
		arr = nil
		for i := 0; i < len(slice); i++ {
			if i != len(slice)-1 {
				arr = append(arr, slice[i])
			}
		}
	}
	return arr, nil
}

func str(str string) []string {
	temp := strings.Split(string(str), "\n")
	return temp
}

func asciiFinal(slice [][]string) {
	result := ""
	var arr []string

	if len(slice) == 0 {
		fmt.Println()
	} else {
		for j := 0; j < 8; j++ {
			for i := 0; i < len(slice); i++ {
				if slice[i][0] == "" {
					slice[i][0] = "      "
				}
				result += slice[i][j]
			}
			if j != 7 {
				result += "\n"
			}
			arr = append(arr, result)
			result = ""
		}
		for _, v := range arr {
			fmt.Print(v)
		}
		fmt.Println()
	}
}

func findNewLine(slice [][]string) {
	var arr [][]string

	for i := 0; i < len(slice); i++ {
		if slice[i][0] == "n" {
			asciiFinal(arr)
			arr = nil
		} else {
			arr = append(arr, slice[i])
		}
	}
}

// Width returns the width of the terminal.
func Width() (uint, error) {
	output, err := size()
	if err != nil {
		return 0, err
	}

	_, width, err := parse(output)

	return width, err
}

func parse(input string) (uint, uint, error) {
	parts := strings.Split(input, " ")

	x, err := strconv.Atoi(parts[0])
	if err != nil {
		return 0, 0, err
	}

	y, err := strconv.Atoi(strings.Replace(parts[1], "\n", "", 1))
	if err != nil {
		return 0, 0, err
	}

	return uint(x), uint(y), nil
}

func size() (string, error) {
	cmd := exec.Command("stty", "size")
	cmd.Stdin = os.Stdin

	out, err := cmd.Output()

	return string(out), err
}
