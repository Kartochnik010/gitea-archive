package utils

func ValidOutput(s string) bool {
	n := len(s)
	if n > 260 || n < 15 || s[:9] != "--output=" || s[n-4:] != ".txt" {
		return false
	}
	name := s[9 : n-4]
	for _, k := range name {
		if !((k >= '0' && k <= '9') || (k >= 'a' && k <= 'z') || (k >= 'A' && k <= 'Z') || k == '_' || k == '.') {
			return false
		}
	}
	return true
}
