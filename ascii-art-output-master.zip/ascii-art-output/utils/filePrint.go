package utils

import (
	"log"
	"os"
)

func PrintArt(numList []int, s, n string) {
	f, err := os.OpenFile(n, os.O_APPEND|os.O_WRONLY, os.ModeAppend)
	if err != nil {
		log.Fatal(err)
	}
	defer f.Close()
	if len(numList) == q { // if number of new lines is equal to len of string boolean onlyEnter will be true
		onlyEnter = true
	}
	if numList[len(numList)-1] == -2 { // if array's last variable is equal to -2 it means that string contains unallowed ASCII value or it is not even an ASCII value at all
		return // returs to main.go without printing anything
	}
	startIndex := 0 // variable to differentiate between new lines
	for i, num := range numList {
		if num == -1 { // if its new line
			if startIndex == i { // if there is no bytes need to be printed from the previous encounter of new line
				_, err := f.WriteString("\n")
				if err != nil {
					log.Fatal(err)
				}
				if i == len(numList)-1 && !onlyEnter {
					_, err := f.WriteString("\n")
					if err != nil {
						log.Fatal(err)
					}
				}
				startIndex++
				continue
			}
			PrintHelper(numList[startIndex:i], s, n) // printing bytes with indexes between [previous encounter of new line+1] and present index

			if i == len(numList)-1 { // prints new line if i is the last index
				_, err := f.WriteString("\n")
				if err != nil {
					log.Fatal(err)
				}
			}

			startIndex = i + 1
			continue
		}
		if i == len(numList)-1 {
			PrintHelper(numList[startIndex:i+1], s, n)
		}
	}
}

func PrintHelper(numList []int, s, n string) { // printing given ASCII values line by line
	f, err := os.OpenFile(n, os.O_APPEND|os.O_WRONLY, os.ModeAppend)
	if err != nil {
		log.Fatal(err)
	}
	defer f.Close()
	for i := 0; i < 8; i++ { // height of text is 8, prints bytes' line by line
		for _, num := range numList {
			readFile, err := os.Open(s)
			if err != nil {
				log.Fatal(err)
			}
			axisLine := ReadLine(readFile, ((num * 9) + 2 + i))
			_, err3 := f.WriteString(axisLine)
			if err3 != nil {
				log.Fatal(err3)
			}
		}
		_, err4 := f.WriteString("\n")
		if err4 != nil {
			log.Fatal(err4)
		}
	}
}
