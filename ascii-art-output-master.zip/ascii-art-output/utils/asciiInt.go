package utils

import (
	"bufio"
	"fmt"
	"io"
)

var (
	q         int     // variable which will be used to count number of '\n' in the string
	onlyEnter = false // boolean which will indicate whether the string contains only new lines
)

func ReadLine(r io.Reader, lineNum int) string { // returns needed line in txt file
	sc := bufio.NewScanner(r)
	lastLine := 0
	line := ""
	for sc.Scan() { // loops until the needed line is reached
		lastLine++
		if lastLine == lineNum {
			return sc.Text()
		}
	}
	return line
}

func AscciiInt(s string) []int { // returns array with corresponding ASCII values of the string entered by user
	ans := make([]int, 0, len(s))

	for i := 0; i < len(s); i++ {

		if (s[i] < 31 || s[i] > 127) && s[i] != '\n' { // prints error message and appends -2 to the array if byte is not an allowed ASCII value (which means the byte's ASCII value is not between 31 and 127 included and not equal to 10)
			fmt.Println("Not ASCII value")
			ans = append(ans, -2)
			return ans
		}
		if s[i] == '\n' { // appends to an array -1 if the string contains new line
			ans = append(ans, -1)
			continue
		}
		if i != len(s)-1 && s[i] == '\\' && s[i+1] == 'n' { // condition which checks if string contains new line
			q++                   // incrementing counter of number of "\n"
			ans = append(ans, -1) // appending -1, which indicates new line
			i++
			continue
		}

		ans = append(ans, int(s[i])-' ') // appends to an array the (ASCII value of the byte - 32)
	}

	return ans
}
