package main

import (
	"bufio"
	"crypto/sha256"
	"fmt"
	"io"
	"log"
	"os"
	"os/exec"
	"strconv"
	"strings"
)

func main() {
	args := os.Args[1:]
	if len(args) != 1 {
		log.Fatalln("Wrong number of arguments.")
	}

	input := strings.Split(args[0], "\\n")
	removeNewline(&input)

	for _, s := range input {
		if s == "" {
			fmt.Println()
			continue
		}
		PrintInput(s)
	}
}

var (
	Store          [128][8]string // Переменная для хранения символов из файла
	terminalLength int            // переменная для длины консоли
)

// Эта функция запускается перед main и считывает файл в Store
func init() {
	if !TxtFileCheck("standard.txt") {
		log.Fatalln("The file was changed.")
	}
	terminalLength = fitConsole()

	f, err := os.Open("standard.txt")
	check("Error opening file:", err)
	defer f.Close()

	scanner := bufio.NewScanner(f)
	order := " !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~" // это порядок символов в файле, нужен чтобы правильно все считать в Store

	for _, r := range order {
		scanner.Scan() // Так как перед каждым символом в файле идет пустая строка, ее нужно пропускать, перед считыванием в Store
		for i := 0; i < 8; i++ {
			scanner.Scan()                    // здесь уже начинается считывание из файла в Store
			Store[int(r)][i] = scanner.Text() // Каждый символ помещается в ячейку под номером своего ascii значенения
		}
	}
}

// Выводит данную строку на консоль символами из файла
func PrintInput(s string) {
	if s == "" {
		return
	}

	for i := 0; i < 8; i++ {
		var tmp string

		for _, r := range s {
			if r < 0 || r > 127 || Store[int(r)][0] == "" {
				fmt.Println("A character is not available.")
				return
			}
			tmp = tmp + Store[int(r)][i]
		}

		if len(tmp) > terminalLength {
			fmt.Println("The input string doesn't fit into terminal.")
			os.Exit(1)
		}
		fmt.Println(tmp)
	}
}

// Проверяет ошибку, выводит ее на консоль с сопроводительным сообщеением в строке, если она есть
func check(s string, e error) {
	if e != nil {
		log.Fatalln(s, e.Error())
	}
}

// Проверяет файл на какие либо изменения, и выдает ошибку, если они были
func TxtFileCheck(fileName string) bool {
	hashStandard := "e194f1033442617ab8a78e1ca63a2061f5cc07a3f05ac226ed32eb9dfd22a6bf"

	file, err := os.Open(fileName)
	if err != nil {
		log.Println(err)
		return false
	}
	defer file.Close()
	buf := make([]byte, 30*1024)
	sha256 := sha256.New()
	for {
		n, err := file.Read(buf)
		if n > 0 {
			_, err := sha256.Write(buf[:n])
			if err != nil {
				log.Fatal(err)
			}
		}
		if err == io.EOF {
			break
		}
		if err != nil {
			log.Printf("Read %d bytes: %v", n, err)
			break
		}
	}
	sum := fmt.Sprintf("%x", sha256.Sum(nil))

	return string(sum) == string(hashStandard)
}

// Определяет длину консоли, чтобы удостоверить, что вводную строку можно распечатать
func fitConsole() int {
	cmd := exec.Command("stty", "size")
	cmd.Stdin = os.Stdin
	out, err := cmd.Output()
	check("Error measuring console size:", err)

	outStr := string(out)
	outStr = strings.TrimSpace(outStr)
	heightWidth := strings.Split(outStr, " ")
	width, err := strconv.Atoi(heightWidth[1])
	check("Error measuring console size:", err)

	return width
}

// Когда в вводной строке нет слов, а только '\n' либо вообще ничего, создается лишняя пустая строка, из-за которой на консоль выводится лишшняя новая линия. Эта функция убирает эту строку.
// "\n" -> "", ""
// "\nHello" -> "", "Hello"
func removeNewline(input *[]string) {
	nowords := true
	for _, s := range *input {
		if len(s) > 0 {
			nowords = false
		}
	}
	if nowords {
		*input = (*input)[1:]
	}
}
