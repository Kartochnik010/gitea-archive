To be able to run the code, first all the files from repo need to be downloaded.

The code acccepts only one string as an argument and prints it on to a console. To do that, type this in terminal:
go run main.go "some string"

The string has certain constraints: 

* Only the characters that are present in the "standard.txt" file can be printed.

* To print special characters backslash (\) needs to be placed before the character:
\" \\

* To add a new line either '\n' or '\\n' can be used.

All the characters that are available are:
 !"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\]^_`abcdefghijklmnopqrstuvwxyz{|}~
(the first character is white space)