package main

import (
	"fmt"
	"os"
)

func main() {
	help := "--insert\n  -i\n    This flag inserts the string into the string passed as argument.\n--order\n  -o\n    This flag will behave like a boolean, if it is called it will order the argument."
	args := os.Args
	iFlag := false
	oFlag := false
	for i := 1; i < len(args); i++ {
		if args[i] == "--insert" || args[i] == "-i" {
			iFlag = true
		} else if args[i] == "--order" || args[i] == "-o" {
			oFlag = true
		} else if args[i] == "--help" || args[i] == "-h" {
			fmt.Print(help)
		} else {
			if iFlag {
				runes := []rune(args[i])
				for i := 0; i < len(runes)-1; i++ {
					for j := 0; j < len(runes)-i-1; j++ {
						if runes[j] > runes[j+1] {
							temp := runes[j]
							runes[j] = runes[j+1]
							runes[j+1] = temp
						}
					}
				}
				fmt.Print(string(runes))
				iFlag = false
			} else if oFlag {
				runes := []rune(args[i])
				for i := 0; i < len(runes)-1; i++ {
					for j := 0; j < len(runes)-i-1; j++ {
						if runes[j] > runes[j+1] {
							temp := runes[j]
							runes[j] = runes[j+1]
							runes[j+1] = temp
						}
					}
				}
				fmt.Print(string(runes))
				oFlag = false
			} else {
				fmt.Print(args[i])
			}
		}
	}
	fmt.Println()
}
