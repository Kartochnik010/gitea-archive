package main

import (
	"fmt"
	"os"
)

func main() {
	args := os.Args[1:]
	errorCount := 0

	position := Atoi(args[1])
	for i := 2; i < len(args); i++ {
		bytes := make([]byte, position)
		file, err := os.Open(args[i])
		if err != nil {
			fmt.Printf(err.Error() + "\n")
			errorCount++
		} else {
			_, error := file.Read(bytes)
			if error != nil {
				fmt.Printf(error.Error() + "\n")
				errorCount++
			} else {
				if i > 2 {
					fmt.Printf("\n")
				}
				if len(args) > 3 {
					fmt.Printf("==> " + args[i] + " <==" + "\n")
				}
				// bytes = data[len(data)-position:]
				fmt.Printf(string(bytes) + "\n")
				defer file.Close()
			}
		}
	}

	if errorCount > 0 {
		os.Exit(1)
	}
}

func Atoi(s string) int {
	runes := []rune(s)
	count := 0
	sign := '+'
	res := 0

	for i := 0; i < len(runes); i++ {
		if (runes[i] < 48 || runes[i] > 57) && res != 0 {
			return 0
		}
		if (runes[i] == '+' || runes[i] == '-') && res == 0 {
			if runes[i] == '-' {
				sign = '-'
			}
			count++
		}
		if runes[i] == ' ' || (runes[i] >= 65 && runes[i] <= 122) {
			return 0
		}
		if count > 1 {
			return 0
		}
		if sign == '-' {
			if runes[i] >= '0' && runes[i] <= '9' {
				res = res*10 - int(runes[i]-'0')
			}
		} else if sign == '+' {
			if runes[i] >= '0' && runes[i] <= '9' {
				res = res*10 + int(runes[i]-'0')
			}
		} else {
			return 0
		}
	}
	return res
}
