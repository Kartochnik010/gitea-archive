package piscine

func IsUpper(s string) bool {
	runes := []rune(s)
	count := 0
	for j := 0; j < len(s); j++ {
		if runes[j] >= 65 && runes[j] <= 90 {
			count++
		}
	}
	if count != len(s) {
		return false
	} else {
		return true
	}
}
