package piscine

func Max(a []int) int {
	max := a[0]
	for i := 0; i < len(a)-1; i++ {
		if max < a[i+1] {
			max = a[i+1]
		}
	}
	return max
}
