package piscine

func Capitalize(s string) string {
	runes := []rune(s)
	flag := false
	for i := 0; i < len(runes); i++ {
		if runes[i] >= 'A' && runes[i] <= 'Z' {
			runes[i] = runes[i] + 32
		}
	}
	for i := 0; i < len(runes); i++ {
		if runes[0] >= 'a' && runes[0] <= 'z' {
			runes[0] = runes[0] - 32
		} else if runes[i] < 97 || runes[i] > 122 {
			if runes[i] >= '0' && runes[i] <= '9' {
				flag = false
			} else {
				flag = true
			}
		} else if runes[i] >= 97 && runes[i] <= 122 && flag {
			runes[i] = runes[i] - 32
			flag = false
		} else {
			flag = false
		}
	}

	return string(runes)
}
