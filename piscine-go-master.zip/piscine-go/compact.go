// package piscine

// func Compact(ptr *[]string) int {
// 	count := 0
// 	for i := 0; i < len(*ptr)-1; i++ {
// 		if (*ptr)[i] != "" {
// 			count++
// 		}
// 	}
// 	for i := 0; i < len(*ptr); i++ {
// 		runes := []rune((*ptr)[i])
// 		toDelete := false
// 		for _, r := range runes {
// 			if r == ' ' {
// 				toDelete = true
// 				break
// 			}
// 		}
// 		if (*ptr)[i] == "" || toDelete {
// 			(*ptr) = append((*ptr)[:i], (*ptr)[i+1:]...)
// 		}
// 	}

// 	return count
// }
package piscine

func Compact(ptr *[]string) int {
	ss := *ptr
	cnt := 0

	for i := 0; i < len(ss); i++ {
		if ss[i] != "" {
			ss[cnt] = ss[i]
			cnt++
		}
	}
	*ptr = ss[0:cnt]
	return cnt
}
