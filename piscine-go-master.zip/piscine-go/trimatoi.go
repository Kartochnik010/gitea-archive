package piscine

func TrimAtoi(s string) int {
	runes := []rune(s)
	count := 0
	sign := '+'
	res := 0

	for i := 0; i < len(runes); i++ {
		if runes[i] == '+' || runes[i] == '-' && res == 0 {
			if runes[i] == '-' {
				sign = '-'
			}
			count++
		}
		if count > 1 {
			return 0
		}
		if sign == '-' {
			if runes[i] >= '0' && runes[i] <= '9' {
				res = res*10 - int(runes[i]-'0')
			}
		} else if sign == '+' {
			if runes[i] >= '0' && runes[i] <= '9' {
				res = res*10 + int(runes[i]-'0')
			}
		} else {
			return 0
		}
	}
	return res
	// runes := []rune(s)
	// count := 0
	// sign := '+'
	// res := 0
	// for i := 0; i < len(runes); i++ {
	// 	if runes[i] == '+' || runes[i] == '-' {
	// 		if runes[i] == '-' {
	// 			sign = '-'
	// 		}
	// 		count++
	// 	}
	// 	if runes[i] == ' ' {
	// 		return 0
	// 	}
	// 	if count > 1 {
	// 		return 0
	// 	}
	// 	if sign == '-' {
	// 		if runes[i] >= '0' && runes[i] <= '9' {
	// 			res = res*10 - int(runes[i]-'0')
	// 		}
	// 	} else if sign == '+' {
	// 		if runes[i] >= '0' && runes[i] <= '9' {
	// 			res = res*10 + int(runes[i]-'0')
	// 		}
	// 	} else {
	// 		return 0
	// 	}
	// }
	// return res
}
