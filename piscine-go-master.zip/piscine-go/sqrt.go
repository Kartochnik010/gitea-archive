package piscine

func Sqrt(nb int) int {
	if nb <= 0 {
		return 0
	}
	var mn int
	for i := 1; i <= nb; i++ {
		if i*i == nb {
			mn = i
		}
	}
	return mn
}
