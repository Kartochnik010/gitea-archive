package piscine

func Index(s string, toFind string) int {
	runes1 := []rune(s)
	runes2 := []rune(toFind)
	count := 0
	index := 0

	if len(toFind) == 0 {
		return 0
	}

	for i := 0; i < len(s); i++ {
		if runes1[i] == runes2[0] && len(toFind) == 1 {
			return i
		}
		if runes1[i] == runes2[0] {
			index = i
			break
		}
	}

	for j := 0; j < len(toFind); j++ {
		for i := index; i < len(s); i++ {
			if runes1[i] == runes2[j] {
				count++
				break
			}
		}
	}

	if count == len(toFind) {
		return index
	} else {
		return -1
	}
}
