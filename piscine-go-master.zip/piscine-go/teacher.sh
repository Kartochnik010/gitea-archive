export X=$(grep 'SEE' streets/Buckingham_Place | awk '{gsub(/SEE INTERVIEW #/, "");print}' )
echo $X
cat interviews/interview-$X
echo $MAIN_SUSPECT