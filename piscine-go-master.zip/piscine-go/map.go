package piscine

func Map(f func(int) bool, a []int) []bool {
	arr := []bool{}
	for _, n := range a {
		arr = append(arr, f(n))
	}
	return arr
}
