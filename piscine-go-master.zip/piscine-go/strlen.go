package piscine

func StrLen(s string) int {
	var count int
	for i := 0; i < len([]rune(s)); i++ {
		count++
	}
	return count
}
