package piscine

func IsPrintable(s string) bool {
	runes := []rune(s)
	count := 0
	for i := 0; i < len(runes); i++ {
		if runes[i] >= 32 && runes[i] <= 255 {
			count++
		}
	}
	if count == len(s) {
		return true
	} else {
		return false
	}
}
