package piscine

import "github.com/01-edu/z01"

func PrintComb2() {
	count := 0
	var flag bool
	for i := '0'; i <= '9'; i++ {
		for j := '0'; j <= '9'; j++ {
			flag = true
			for l := i; l <= '9'; l++ {
				if flag {
					for k := j + 1; k <= '9'; k++ {
						z01.PrintRune(i)
						z01.PrintRune(j)
						z01.PrintRune(' ')
						z01.PrintRune(l)
						z01.PrintRune(k)
						count++
						if count != 4950 {
							z01.PrintRune(',')
							z01.PrintRune(' ')
						}
					}
				} else {
					for k := '0'; k <= '9'; k++ {
						z01.PrintRune(i)
						z01.PrintRune(j)
						z01.PrintRune(' ')
						z01.PrintRune(l)
						count++
						z01.PrintRune(k)
						if count != 4950 {
							z01.PrintRune(',')
							z01.PrintRune(' ')
						}
					}
				}
				flag = false
			}
		}
	}
	z01.PrintRune('\n')
}
