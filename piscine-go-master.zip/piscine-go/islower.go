package piscine

func IsLower(s string) bool {
	runes := []rune(s)
	count := 0

	for j := 0; j < len(s); j++ {
		if runes[j] >= 97 && runes[j] <= 122 {
			count++
		}
	}
	if count != len(s) {
		return false
	} else {
		return true
	}
}
