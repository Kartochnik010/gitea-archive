package piscine

func NRune(s string, n int) rune {
	runes := []rune(s)
	if n > len(s) || n < 1 {
		return 0
	} else {
		return runes[n-1]
	}
}
