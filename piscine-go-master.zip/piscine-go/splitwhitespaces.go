package piscine

func SplitWhiteSpaces(s string) []string {
	strs := []string{}
	runes := []rune(s)
	str := ""
	for i := 0; i < len(runes); i++ {
		if runes[i] == ' ' || i == len(runes)-1 {
			if str == "" {
				continue
			}
			if i == len(runes)-1 {
				str += string(runes[i])
			}
			strs = append(strs, str)
			str = ""
		} else {
			str += string(runes[i])
		}
	}
	return strs
}
