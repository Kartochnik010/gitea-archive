find . -name '*.sh' -printf "%f\n" | awk '{gsub(/.sh/, ""); print}' | sort -r
