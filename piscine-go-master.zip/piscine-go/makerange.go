package piscine

func MakeRange(min, max int) []int {
	if (min == 0 && max == 0) || min > max {
		return nil
	}
	nar := make([]int, max-min)
	for i := 0; i < len(nar); i++ {
		nar[i] = min
		min++
	}
	return nar
}
