package main

import (
	"os"

	"github.com/01-edu/z01"
)

func main() {
	args := os.Args
	for i := 0; i < len(args)-1; i++ {
		for j := 1; j < len(args)-i-1; j++ {
			if args[j] < args[j+1] {
				temp := args[j]
				args[j] = args[j+1]
				args[j+1] = temp
			}
		}
	}
	for i := len(args) - 1; i > 0; i-- {
		runes := []rune(args[i])
		for i := 0; i < len(runes); i++ {
			z01.PrintRune(runes[i])
		}
		z01.PrintRune('\n')
	}
}
