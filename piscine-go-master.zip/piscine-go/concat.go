package piscine

func Concat(str1 string, str2 string) string {
	return str1 + str2
}
