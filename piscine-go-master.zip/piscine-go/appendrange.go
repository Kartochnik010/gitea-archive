package piscine

func AppendRange(min, max int) []int {
	arr := []int{}
	if (min == 0 && max == 0) || min > max {
		arr = nil
		return arr
	}
	for i := min; i < max; i++ {
		arr = append(arr, i)
	}
	return arr
}
