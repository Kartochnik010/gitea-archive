package piscine

import "github.com/01-edu/z01"

func PrintNbrInOrder(n int) {
	if n == 0 {
		z01.PrintRune('0')
		return
	}
	test := n
	count := 0

	for {
		if test == 0 {
			break
		}
		test = test / 10
		count++
	}
	arr := make([]int, count+1)
	for i := 0; i < count; i++ {
		arr[i] = n % 10
		n = n / 10
	}

	for i := 0; i < len(arr)-1; i++ {
		for j := 0; j < len(arr)-i-1; j++ {
			if arr[j] < arr[j+1] {
				temp := arr[j]
				arr[j] = arr[j+1]
				arr[j+1] = temp
			}
		}
	}

	for i := count - 1; i >= 0; i-- {
		z01.PrintRune('0' + rune(arr[i]))
	}
}
