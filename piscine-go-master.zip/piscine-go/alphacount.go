package piscine

func AlphaCount(s string) int {
	runes := []rune(s)
	count := 0

	for j := 0; j < len(s); j++ {
		for i := 'a'; i <= 'z'; i++ {
			if runes[j] == i {
				count++
			}
		}
		for i := 'A'; i <= 'Z'; i++ {
			if runes[j] == i {
				count++
			}
		}
	}
	return count
}
