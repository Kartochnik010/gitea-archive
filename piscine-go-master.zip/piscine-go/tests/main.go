package main

import (
	"fmt"
	"piscine"
)

func f(a, b int) int {
	if a > b {
		return 1
	} else if a == b {
		return 0
	} else {
		return -1
	}
}

func main() {
	// s := "Hello World!"
	// s = StrRev(s)
	// fmt.Println(s)
	// piscine.QuadA(5, 3)
	// fmt.Println()
	// piscine.QuadA(5, 1)
	// fmt.Println()
	// piscine.QuadA(1, 1)
	// fmt.Println()
	// piscine.QuadA(1, 5)
	// piscine.PrintComb2()
	// s := "ZkMTLXZjfh2Fr    WyTKQW8PD1pAA    1TlAzweZR2L6k    FEmfHggIrw1Oa    S8WHXfk2Yttgl    JJlgsgdl2f5wC    c2dlRFXKEztrJ    UVcCQWXgQ7ISw"

	a := []int{4, 4, 3, 3, 2, 1, 1}
	unmatch := piscine.Unmatch(a)
	fmt.Println(unmatch)
	// s := "4SFKIk0CSAJy1[<>abc<>]gcLvoRsK46ino[<>abc<>]ZEPGGOV430OVk[<>abc<>]9ajvtvbfryY7c[<>abc<>]P16pnpWXuKSXP[<>abc<>]GPj1bnJPsAlaU[<>abc<>]5NA7Y1gBmKHvo[<>abc<>]958IIDBgpaWul"
	// s := "6ADusKbC4m5P5[<>abc<>]Ce2Bh2EUbIe1g[<>abc<>]MlorbA1QDvOp3[<>abc<>]zsIeFpIdwA9af[<>abc<>]YZiBgxs1MGP3D[<>abc<>]uB2rMwOl2FsAq[<>abc<>]s0wLbYnMqel1p[<>abc<>]h0XSi8BvL4SLR"
	// fmt.Printf("%#v\n", piscine.Split(s, "    "))
	// piscine.Sudoku()
	// a := piscine.SplitWhiteSpaces("Hello how are you?")
	// piscine.PrintWordsTables(a)
	// fmt.Printf("%#v\n", piscine.SplitWhiteSpaces("X:V;=wG5PIH.y S`@_s'R&<)b`K gJ8{PzS\\C!oL> /<\"Gk:TZR=6%  uZ)g)j-taL2Q. 25c~;'bc!{(Wr @Ni&JS?qW#S[e ei}|][xs<XZm&"))
	// piscine.PrintNbr(123)
	// z01.PrintRune('\n')
	// fmt.Println(piscine.Capitalize("Hello! How are you? How+are+things+4you?"))
	// fmt.Println(piscine.Capitalize("`x/z'cl9!uZkX"))
	// fmt.Println(piscine.Capitalize("C\"vsjV=PvJ+=c"))
	// fmt.Println(piscine.Capitalize("eaq,K<ZRuk$Yg"))
	// piscine.Capitalize("Hello! How are you? How+are+things+4you?")
	// piscine.PrintNbrInOrder(321)

	// fmt.Println(piscine.IsPrintable("hY+.kAMD\"eRhu"))
	// fmt.Println(piscine.IsPrintable("Hello"))
	// fmt.Println(piscine.IsPrintable("Hello\n"))
	// fmt.Println(strings.Index("chicken", ""))
	// fmt.Println(piscine.Index("$i@0c+%WM\\p+c", "+%WM\\"))
	// fmt.Println(piscine.Index("6Ja#*?T-N60aU", "Ja#*?T-N60a"))
	// fmt.Println(piscine.Index("Salut!", "alu"))
	// fmt.Println(piscine.Index("Ola!", "hOl"))
}

func BasicAtoi(s string) int {
	runes := []rune(s)
	// var newrunes []rune
	var nums []int
	count := 0
	for i := 0; i < len(s); i++ {
		for j := '1'; j <= '9'; j++ {
			if runes[i] == j {
				// newrunes[count] = runes[i]
				nums[count] = int(runes[i])
				count++
			}
		}
	}
	// st := "123"
	return 0
}
