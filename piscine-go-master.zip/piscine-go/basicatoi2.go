package piscine

func BasicAtoi2(s string) int {
	runes := []rune(s)
	res := 0
	for i := 0; i < len(runes); i++ {
		if runes[i] >= '0' && runes[i] <= '9' {
			res = res*10 + int(runes[i]-'0')
		} else {
			return 0
		}
	}
	return res
}
