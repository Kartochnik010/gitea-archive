package main

import (
	"io/ioutil"
	"os"

	"github.com/01-edu/z01"
)

func main() {
	arguments := os.Args[1:]
	length := 0
	for l := range arguments {
		length = l + 1
	}

	if length == 0 {
		input, err := ioutil.ReadAll(os.Stdin)
		for _, j := range string(input) {
			z01.PrintRune(j)
		}
		if err != nil {
			printError(err)
		}
	}

	first := true

	for _, arg := range arguments {
		file, err := os.Open(arg)
		if err != nil {
			printError(err)
		}

		f, err := ioutil.ReadAll(file)

		if !first {
			// z01.PrintRune('\n')
		}
		first = false
		for _, text := range string(f) {
			z01.PrintRune(text)
		}

		file.Close()
	}
}

func printError(err error) {
	for _, e := range "ERROR: " + err.Error() {
		z01.PrintRune(e)
	}
	z01.PrintRune('\n')
	os.Exit(1)
}
