package piscine

func Split(s, sep string) []string {
	strs := []string{}
	runes := []rune(s)
	runesep := []rune(sep)
	str := ""
	isSep := false
	isAlready := false

	for i := 0; i < len(runes); i++ {
		if runes[i] == runesep[0] && (runes[i+1] == runesep[1] && len(runesep) != 1) {
			if str != "" {
				strs = append(strs, str)
				str = ""
				isAlready = true
			}
		} else {
			if len(runesep) != 1 && isAlready {
				for k := 1; k < len(runesep); k++ {
					if runes[i] == runesep[k] {
						isSep = true
						if k == len(runesep)-1 {
							isAlready = false
						}
						break
					}
				}
				if isSep {
					isSep = false
					continue
				}
			}
			if i == len(runes)-1 {
				str += string(runes[i])
				strs = append(strs, str)
				str = ""
			}
			str += string(runes[i])
		}
	}

	return strs
}
