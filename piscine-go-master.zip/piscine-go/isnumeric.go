package piscine

func IsNumeric(s string) bool {
	if s == " " || s == "" {
		return false
	}
	runes := []rune(s)
	count := 0
	for i := 0; i < len(runes); i++ {
		if runes[i] >= '0' && runes[i] <= '9' {
			count++
		}
	}
	if count == len(s) {
		return true
	} else {
		return false
	}
}
