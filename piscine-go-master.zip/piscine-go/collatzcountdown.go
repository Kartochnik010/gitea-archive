package piscine

func CollatzCountdown(start int) int {
	count := 0
	for {
		if start > 1 {
			if start%2 == 0 {
				start /= 2
				count++
			} else {
				start = (start * 3) + 1
				count++
			}
		} else if start == 1 {
			return count
		} else {
			return -1
		}
	}
}
