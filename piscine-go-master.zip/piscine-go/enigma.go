package piscine

func Enigma(a ***int, b *int, c *******int, d ****int) {
	***a, *b = *b, ***a
	*b, ****d = ****d, *b
	*******c, ****d = ****d, *******c
}
