package piscine

import (
	"fmt"

	"github.com/01-edu/z01"
)

func QuadA(x int, y int) {
	count := 0
	for i := 0; i < y; i++ {
		if count == 0 || count == y-1 {
			// horizontal
			for i := 0; i < x; i++ {
				if i == 0 || i == x-1 {
					z01.PrintRune('o')
				} else {
					z01.PrintRune('-')
				}
			}
			fmt.Println()
		} else {
			// vertical
			z01.PrintRune('|')
			if x != 1 {

				for j := 0; j < x-2; j++ {
					z01.PrintRune(' ')
				}
				z01.PrintRune('|')
			}
			z01.PrintRune('\n')
		}
		count++
	}
}

func QuadB(x int, y int) {
	count := 0
	for i := 0; i < y; i++ {
		if count == 0 || count == y-1 {
			// horizontal
			for i := 0; i < x; i++ {
				if i == 0 && count == 0 {
					z01.PrintRune('/')
				} else if i == x-1 && count == 0 {
					z01.PrintRune('\\')
				} else if i == 0 && count == y-1 {
					z01.PrintRune('\\')
				} else if i == x-1 && count == y-1 {
					z01.PrintRune('/')
				} else {
					z01.PrintRune('*')
				}
			}
			z01.PrintRune('\n')
		} else {
			// vertical
			z01.PrintRune('*')
			if x != 1 {

				for j := 0; j < x-2; j++ {
					z01.PrintRune(' ')
				}
				z01.PrintRune('*')
			}
			z01.PrintRune('\n')
		}
		count++
	}
}

func QuadC(x int, y int) {
	count := 0
	for i := 0; i < y; i++ {
		if count == 0 || count == y-1 {
			// horizontal
			for i := 0; i < x; i++ {
				if i == 0 && count == 0 {
					z01.PrintRune('A')
				} else if i == x-1 && count == 0 {
					z01.PrintRune('A')
				} else if i == 0 && count == y-1 {
					z01.PrintRune('C')
				} else if i == x-1 && count == y-1 {
					z01.PrintRune('C')
				} else {
					z01.PrintRune('B')
				}
			}
			z01.PrintRune('\n')
		} else {
			// vertical
			z01.PrintRune('B')
			if x != 1 {

				for j := 0; j < x-2; j++ {
					z01.PrintRune(' ')
				}
				z01.PrintRune('B')
			}
			z01.PrintRune('\n')
		}
		count++
	}
}

func QuadD(x int, y int) {
	count := 0
	for i := 0; i < y; i++ {
		if count == 0 || count == y-1 {
			// horizontal
			for i := 0; i < x; i++ {
				if i == 0 && count == 0 {
					z01.PrintRune('A')
				} else if i == x-1 && count == 0 {
					z01.PrintRune('C')
				} else if i == 0 && count == y-1 {
					z01.PrintRune('A')
				} else if i == x-1 && count == y-1 {
					z01.PrintRune('C')
				} else {
					z01.PrintRune('B')
				}
			}
			z01.PrintRune('\n')
		} else {
			// vertical
			z01.PrintRune('B')
			if x != 1 {

				for j := 0; j < x-2; j++ {
					z01.PrintRune(' ')
				}
				z01.PrintRune('B')
			}
			z01.PrintRune('\n')
		}
		count++
	}
}

func QuadE(x int, y int) {
	count := 0
	for i := 0; i < y; i++ {
		if count == 0 || count == y-1 {
			// horizontal
			for i := 0; i < x; i++ {
				if i == 0 && count == 0 {
					z01.PrintRune('A')
				} else if i == x-1 && count == 0 {
					z01.PrintRune('C')
				} else if i == 0 && count == y-1 {
					z01.PrintRune('C')
				} else if i == x-1 && count == y-1 {
					z01.PrintRune('A')
				} else {
					z01.PrintRune('B')
				}
			}
			z01.PrintRune('\n')
		} else {
			// vertical
			z01.PrintRune('B')
			if x != 1 {

				for j := 0; j < x-2; j++ {
					z01.PrintRune(' ')
				}
				z01.PrintRune('B')
			}
			z01.PrintRune('\n')
		}
		count++
	}
}
