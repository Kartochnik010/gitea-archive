# todo app

#### No DB
#### Supports static files: js, css
