package main

import (
	"github.com/01-edu/z01"
)

func main() {
	for i := '9'; i >= '0'; i-- {
		z01.PrintRune(i)
	}
	z01.PrintRune('\n')
}
