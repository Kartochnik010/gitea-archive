package main

import (
	"fmt"
	"os"
)

func main() {
	args := os.Args[1:]
	if len(args) == 1 {
		n := Atoi(args[0])
		if n >= 4000 || n <= 0 {
			fmt.Println("ERROR: cannot convert to roman digit")
			return
		}

		nums := []int{1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1}
		rnums := []string{"M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I"}
		rcalc := []string{"M", "(C-M)", "D", "(C-D)", "C", "(X-C)", "L", "(X-L)", "X", "(I-X)", "V", "(I-V)", "I"}

		res := ""
		rescalc := ""

		for i := 0; n != 0; i++ {
			fmt.Println(i, ":  ", n, nums[i], res)

			if n-nums[i] >= 0 {
				n -= nums[i]
				res += rnums[i]
				rescalc += rcalc[i] + "+"
				i--
			}
		}

		fmt.Println(rescalc[:len(rescalc)-1])

		fmt.Println(res)
	}
}

func Atoi(s string) int {
	runes := []rune(s)
	res := 0
	for i, j := len(runes)-1, 1; i >= 0; i-- {
		res += (int(runes[i]) - int(rune('0'))) * j
		j *= 10
	}
	return res
}
