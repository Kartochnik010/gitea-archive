package checkRequest

import (
	"fmt"
	"html/template"
	"net/http"

	"groupie/internal/parseJson"
)

// A function that checks the request method
func CheckMethod(r *http.Request) int {
	if r.Method != http.MethodGet {
		return http.StatusMethodNotAllowed
	}
	return http.StatusOK
}

// The function checks whether the current path of the request URL matches the template
func CheckPath(r *http.Request, path string) int {
	if r.URL.Path != path {
		return http.StatusNotFound
	}

	return http.StatusOK
}

// Function for reading the template file and writing the content to the HTTP response body
func CheckArtists(w http.ResponseWriter, path string) int {
	tmpl, err := template.ParseFiles(path)
	if err != nil {
		return http.StatusInternalServerError
	}

	artist, status := parseJson.GetArtists("https://groupietrackers.herokuapp.com/api/artists")
	if status != http.StatusOK {
		return status
	}

	err = tmpl.Execute(w, artist)
	if err != nil {
		return http.StatusInternalServerError
	}

	return http.StatusOK
}

// Function for reading the template file and writing the content to the HTTP response body
func CheckArtist(w http.ResponseWriter, r *http.Request, path string) int {
	tmpl, err := template.ParseFiles(path)
	if err != nil {
		return http.StatusInternalServerError
	}

	artist, status := parseJson.GetArtist(w, r)
	if status != http.StatusOK {
		return status
	}

	err = tmpl.Execute(w, artist)
	if err != nil {
		return http.StatusInternalServerError
	}

	return http.StatusOK
}

// A function that returns a string, the status of the request
func CheckStatus(status int) string {
	switch status {
	case http.StatusNotFound:
		return fmt.Sprintf("%d %s", http.StatusNotFound, http.StatusText(http.StatusNotFound))
	case http.StatusInternalServerError:
		return fmt.Sprintf("%d %s", http.StatusInternalServerError, http.StatusText(http.StatusInternalServerError))
	}
	return ""
}
