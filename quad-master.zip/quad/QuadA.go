package piscine

import "github.com/01-edu/z01"

func QuadA(x, y int) {
	// first line
	if x <= 0 || y <= 0 {
		return
	}
	if x >= 1 {
		z01.PrintRune('o')
	}
	for i := 0; i < x-2; i++ {
		z01.PrintRune('-')
	}
	if x > 1 {
		z01.PrintRune('o')
	}
	z01.PrintRune('\n')

	// length
	for a := 0; a < y-2; a++ {
		if y >= 1 {
			z01.PrintRune('|')
		}
		for i := 0; i < x-2; i++ {
			z01.PrintRune(' ')
		}
		if y > 1 && x > 1 {
			z01.PrintRune('|')
		}
		z01.PrintRune('\n')
	}

	if y > 1 && x > 0 {
		if x == 1 {
			z01.PrintRune('o')
			z01.PrintRune('\n')
		} else {
			z01.PrintRune('o')
		}
	}
	if y > 1 && x > 1 {
		for i := 0; i < x-2; i++ {
			z01.PrintRune('-')
		}
	}
	if y > 1 && x > 1 {
		z01.PrintRune('o')
		z01.PrintRune('\n')
	}
}
