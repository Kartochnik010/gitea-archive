to test our code simply type

$ go run main/main.go
