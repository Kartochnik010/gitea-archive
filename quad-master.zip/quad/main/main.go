package main

import (
	"piscine"

	"github.com/01-edu/z01"
)

func main() {
	// program 1
	piscine.QuadA(5, 3)
	z01.PrintRune('\n')
	piscine.QuadB(5, 3)
	z01.PrintRune('\n')
	piscine.QuadC(5, 3)
	z01.PrintRune('\n')
	piscine.QuadD(5, 3)
	z01.PrintRune('\n')
	piscine.QuadE(5, 3)
	z01.PrintRune('\n')
	// program 2

	piscine.QuadA(5, 1)
	z01.PrintRune('\n')
	piscine.QuadB(5, 1)
	z01.PrintRune('\n')
	piscine.QuadC(5, 1)
	z01.PrintRune('\n')
	piscine.QuadD(5, 1)
	z01.PrintRune('\n')
	piscine.QuadE(5, 1)
	z01.PrintRune('\n')
	// program 3

	piscine.QuadA(1, 1)
	z01.PrintRune('\n')
	piscine.QuadB(1, 1)
	z01.PrintRune('\n')
	piscine.QuadC(1, 1)
	z01.PrintRune('\n')
	piscine.QuadD(1, 1)
	z01.PrintRune('\n')
	piscine.QuadE(1, 1)
	z01.PrintRune('\n')
	// program 4

	piscine.QuadA(1, 5)
	z01.PrintRune('\n')
	piscine.QuadB(1, 5)
	z01.PrintRune('\n')
	piscine.QuadC(1, 5)
	z01.PrintRune('\n')
	piscine.QuadD(1, 5)
	z01.PrintRune('\n')
	piscine.QuadE(1, 5)
}
