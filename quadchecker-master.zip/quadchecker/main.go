package main

import (
	"bufio"
	"fmt"
	"os"
)

func counter(output []rune) (x, y int) {
	countX := 0
	countY := 0
	flag := true
	for _, s := range output {
		if s == '\n' {
			countY++
			flag = false
		} else {
			if flag == true {
				countX++
			}
		}
	}
	return countX, countY
}

func main() {
	reader := bufio.NewScanner(os.Stdin)
	// fmt.Print(reader)
	var output []rune
	inputStr := ""
	str := []string{}
	for reader.Scan() {
		inputStr = inputStr + reader.Text() + "\n"
	}

	for _, a := range inputStr {
		output = append(output, a)
	}
	x, y := counter(output)
	strX := printNbr(x)
	strY := printNbr(y)

	if QuadA(x, y) == inputStr {
		str = append(str, "[quadA]"+" "+"["+strX+"]"+" "+"["+strY+"]"+" ")
	}
	if QuadB(x, y) == inputStr {
		str = append(str, "[quadB]"+" "+"["+strX+"]"+" "+"["+strY+"]"+" ")
	}
	if QuadC(x, y) == inputStr {
		str = append(str, "[quadC]"+" "+"["+strX+"]"+" "+"["+strY+"]"+" ")
	}
	if QuadD(x, y) == inputStr {
		str = append(str, "[quadD]"+" "+"["+strX+"]"+" "+"["+strY+"]"+" ")
	}
	if QuadE(x, y) == inputStr {
		str = append(str, "[quadE]"+" "+"["+strX+"]"+" "+"["+strY+"]"+" ")
	}

	if len(str) == 0 {
		fmt.Println("Not a Raid function")
		return
	}

	for i := 0; i < len(str)-1; i++ {
		fmt.Print(" " + str[i] + "||" + " ")
	}
	fmt.Println(str[len(str)-1])
}

func QuadA(x, y int) string {
	result := ""
	if x >= 1 && y >= 1 {
		for j := 0; j < y; j++ {
			for i := 0; i < x; i++ {
				if i == 0 || i == x-1 {
					if j == 0 || j == y-1 {
						result += "o"
					} else {
						result += "|"
					}
				} else {
					if j == 0 || j == y-1 {
						result += "-"
					} else {
						result += " "
					}
				}
			}
			result += "\n"
		}
	}
	return result
}

func QuadB(x, y int) string {
	result := ""
	if x >= 1 && y >= 1 {
		for j := 0; j < y; j++ {
			for i := 0; i < x; i++ {
				if i == 0 {
					if j == 0 {
						result += "/"
					} else if j == y-1 {
						result += "\\"
					} else {
						result += "*"
					}
				} else if i == x-1 {
					if j == 0 {
						result += "\\"
					} else if j == y-1 {
						result += "/"
					} else {
						result += "*"
					}
				} else {
					if j == 0 || j == y-1 {
						result += "*"
					} else {
						result += " "
					}
				}
			}
			result += "\n"
		}
	}
	return result
}

func QuadC(x, y int) string {
	result := ""
	if x >= 1 && y >= 1 {
		for j := 0; j < y; j++ {
			for i := 0; i < x; i++ {
				if i == 0 || i == x-1 {
					if j == 0 {
						result += "A"
					} else if j == y-1 {
						result += "C"
					} else {
						result += "B"
					}
				} else {
					if j == 0 || j == y-1 {
						result += "B"
					} else {
						result += " "
					}
				}
			}
			result += "\n"
		}
	}
	return result
}

func QuadD(x, y int) string {
	result := ""
	if x >= 1 && y >= 1 {
		for j := 0; j < y; j++ {
			for i := 0; i < x; i++ {
				if i == 0 {
					if j == 0 || j == y-1 {
						result += "A"
					} else {
						result += "B"
					}
				} else if i == x-1 {
					if j == 0 || j == y-1 {
						result += "C"
					} else {
						result += "B"
					}
				} else {
					if j == 0 || j == y-1 {
						result += "B"
					} else {
						result += " "
					}
				}
			}
			result += "\n"
		}
	}
	return result
}

func QuadE(x, y int) string {
	result := ""
	if x >= 1 && y >= 1 {
		for j := 0; j < y; j++ {
			for i := 0; i < x; i++ {
				if i == 0 {
					if j == 0 {
						result += "A"
					} else if j == y-1 {
						result += "C"
					} else {
						result += "B"
					}
				} else if i == x-1 {
					if j == 0 {
						result += "C"
					} else if j == y-1 {
						result += "A"
					} else {
						result += "B"
					}
				} else {
					if j == 0 || j == y-1 {
						result += "B"
					} else {
						result += " "
					}
				}
			}
			result += "\n"
		}
	}
	return result
}

func printNbr(n int) string {
	res := ""

	if n/10 != 0 {
		res = res + printNbr(n/10)
	}
	mod := '0'
	for i := 0; i < (n % 10); i++ {
		mod++
	}
	if mod == '0' {
		res = res + "0"
	} else if mod == '1' {
		res = res + "1"
	} else if mod == '2' {
		res = res + "2"
	} else if mod == '3' {
		res = res + "3"
	} else if mod == '4' {
		res = res + "4"
	} else if mod == '5' {
		res = res + "5"
	} else if mod == '6' {
		res = res + "6"
	} else if mod == '7' {
		res = res + "7"
	} else if mod == '8' {
		res = res + "8"
	} else if mod == '9' {
		res = res + "9"
	}

	return res
}
