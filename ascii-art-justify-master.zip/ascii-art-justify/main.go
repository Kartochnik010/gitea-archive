package main

import (
	"bufio"
	"crypto/sha256"
	"fmt"
	"io/ioutil"
	"log"
	"os"
	"os/exec"
	"strconv"
)

var (
	out     bool
	justify string
)

func main() {
	if len(os.Args) == 1 || len(os.Args) > 4 {
		log.Fatal("Incorrect number of arguments")
	}
	out = false
	word := InputChecker(os.Args[1])
	nameOfDictionary := "standard.txt"
	dictionary := CreateDictionary(nameOfDictionary)
	letters := CreateLetters(dictionary)
	fileOutputName := ""

	if len(os.Args) > 2 {
		nameOfDictionary = os.Args[2] + ".txt"
		dictionary = CreateDictionary(nameOfDictionary)
		letters = CreateLetters(dictionary)
	}

	if len(os.Args) == 4 {
		if os.Args[3][:9] == "--output=" {
			NameChecker(os.Args[3], 1)
			out = true
			fileOutputName = os.Args[3][9:]
			Filing(fileOutputName, CreateResultString(word, letters))
		} else if os.Args[3][:8] == "--align=" {
			NameChecker(os.Args[3], 2)
			justify = os.Args[3][8:]
			fmt.Print(CreateResultString(word, letters))
		} else {
			log.Fatal("Usage: go run . [STRING] [BANNER] [OPTION]\n\nEX: go run . something standard --output=<fileName.txt>")
		}
	} else {
		fmt.Print(CreateResultString(word, letters))
	}
}

func InputChecker(word string) string {
	buf := ""
	for _, value := range word {
		if value == 10 {
			buf += "\\"
			buf += "n"
			continue
		}
		if value < 32 || value > 127 {
			log.Fatal("Invalid input")
		}
		buf += string(value)
	}
	return buf
}

func NameChecker(str string, i int) string {
	if i == 1 && (str[:9] != "--output=" || str[len(os.Args[3])-4:] != ".txt") {
		log.Fatal("Usage: go run . [STRING] [BANNER] [OPTION]\n\nEX: go run . something standard --output=<fileName.txt>")
	} else if i == 2 && (str[:8] != "--align=" || (str[8:] != "center" && str[8:] != "right" && str[8:] != "left" && str[8:] != "justify")) {
		log.Fatal("Usage: go run . [STRING] [BANNER] [OPTION]\n\nEX: go run . something standard --align=right")
	}
	return str[9:]
}

func CreateDictionary(nameOfDictionary string) []string {
	var dictionary []string
	readFile, err := os.Open(nameOfDictionary)
	if err != nil {
		log.Fatal(err)
	}
	defer readFile.Close()

	fileScanner := bufio.NewScanner(readFile)
	fileScanner.Split(bufio.ScanLines)

	for fileScanner.Scan() {
		dictionary = append(dictionary, fileScanner.Text())
	}

	DictionaryChecker(nameOfDictionary)

	return dictionary
}

func DictionaryChecker(nameOfDictionary string) {
	file, _ := os.ReadFile(nameOfDictionary)
	sum := sha256.Sum256(file)
	sumS := fmt.Sprintf("%x", sum)
	if sumS != "26b94d0b134b77e9fd23e0360bfd81740f80fb7f6541d1d8c5d85e73ee550f73" && sumS != "e194f1033442617ab8a78e1ca63a2061f5cc07a3f05ac226ed32eb9dfd22a6bf" && sumS != "a57beec43fde6751ba1d30495b092658a064452f321e221d08c3ac34a9dc1294" {
		log.Fatal("Dictionary file has been changed")
	}
}

func MaxSymbol(str string) int {
	runes := []rune(str)
	for i := len(runes) - 1; i >= 0; i-- {
		if runes[i] != ' ' {
			return i + 1
		}
	}
	return 0
}

func CreateLetters(dictionary []string) [][]string {
	var letters [][]string
	var buf []string
	k := 0
	for i := 1; i < len(dictionary); i++ {
		buf = append(buf, dictionary[i])
		k++
		if k == 8 {
			i++
			k = 0
			letters = append(letters, buf)
			buf = nil
		}
	}
	var maxLenght []int
	k = 0
	for word := 0; word < len(letters); word++ {
		maxLenght = append(maxLenght, MaxSymbol(letters[word][0]))
		for i := 0; i < 8; i++ {
			if maxLenght[k] < MaxSymbol(letters[word][i]) {
				maxLenght[k] = MaxSymbol(letters[word][i])
			}
		}
		k++
	}
	return letters
}

func CreateResultString(word string, letters [][]string) string {
	runes := []rune(word)
	line := ""

	if len(runes) == 0 {
		return line
	}
	buffer := ""
	flag := true
	for i := 0; i < len(runes); i++ {
		buffer += string(runes[i])
		if flag && i == 0 && runes[i] == 92 && runes[i+1] == 110 {
			flag = false
			buffer = buffer[:len(buffer)-1]
			line += "\n"
			i++
			continue
		}
		if runes[i] == 92 && runes[i+1] == 110 {
			buffer = buffer[:len(buffer)-1]
			if len(buffer) == 0 {
				line += "\n"
			} else if i == len(runes)-2 {
				line += AddLetter(letters, buffer)
				line += "\n"
			} else {
				line += AddLetter(letters, buffer)
			}
			i++
			buffer = ""
			continue
		}
	}
	if buffer != "" {
		line += AddLetter(letters, buffer)
	}
	return line
}

func AddLetter(letters [][]string, str string) string {
	if str == "" {
		return ""
	}
	runes := []rune(str)
	line := ""
	if out {
		for j := 0; j < 8; j++ {
			for o := 0; o < len(runes); o++ {
				if runes[o] != 10 {
					line += letters[runes[o]-32][j]
				}
			}
			line += "\n"
		}
	} else {

		arr := LetterOptimise(letters, str)
		for i := 0; i < len(arr); i++ {
			line += arr[i]
		}
	}
	/*else if justify != "" {
		if justify == "right" {


		} else if justify == "center" {
		} else if justify == "left" {
		} else if justify == "justify" {
		} else {
			log.Fatal("Usage: go run . [STRING] [BANNER] [OPTION]\n\nEX: go run . something standard --align=right")
		}
	} */
	return line
}

func LetterOptimise(letters [][]string, str string) []string {
	runes := []rune(str)
	line := ""
	u := 1
	le := 0
	g := 0
	k := 0

	var arr []string

	for i := 0; i < u; i++ {

		for j := g; j < len(runes); j++ {

			k += len(letters[runes[j]-32][0])

			if k > LenghtCmd() {

				le = j
				u++
				k -= len(letters[runes[j]-32][0])

				break
			}
			if j == len(runes)-1 {
				le = len(runes)
			}

		}
		space := 0

		for o := g; o < le; o++ {
			if runes[o] == ' ' {
				space++
			}
		}
		n := 0
		if space != 0 && (LenghtCmd()-k)%space == 0 {
			n = (LenghtCmd() - k - 1) / space
		} else if space != 0 {
			n = (LenghtCmd() - k - 1) / space
		} else {
			n = (LenghtCmd() - k - 1)
		}

		for j := 0; j < 8; j++ {

			for o := g; o < le; o++ {
				if o == g && justify == "right" {
					for i := 0; i < LenghtCmd()-k-1; i++ {
						line += " "
					}
				}
				if o == g && justify == "center" {
					n = 0
					if (LenghtCmd()-k-1)%2 == 0 {
						n = (LenghtCmd() - k - 1) / 2
					} else {
						n = (LenghtCmd()-k-1)/2 - 1
					}
					for i := 0; i < n; i++ {
						line += " "
					}
				}
				if runes[o] == ' ' && justify == "justify" {
					// fmt.Println(LenghtCmd(), k, space)

					for i := 0; i < n+len(letters[runes[o]-32][j]); i++ {
						line += " "
					}

					continue

				}
				if runes[o] != 10 {
					line += letters[runes[o]-32][j]
				}

				if o == le-1 && space == 0 && justify == "justify" {
					for i := 0; i < LenghtCmd()-k-1; i++ {
						line += " "
					}
				}
				if o == le-1 && justify == "left" {
					for i := 0; i < LenghtCmd()-k-1; i++ {
						line += " "
					}
				}
				if o == le-1 && justify == "center" {
					n = 0
					if (LenghtCmd()-k-1)%2 == 0 {
						n = (LenghtCmd() - k - 1) / 2
					} else {
						n = (LenghtCmd()-k-1)/2 + 2
					}
					for i := 0; i < n; i++ {
						line += " "
					}
				}

			}

			line += "\n"
		}

		arr = append(arr, line)
		line = ""
		g = le
		space = 0
		k = 0

	}
	return arr
}

func LenghtCmd() int {
	cmd := exec.Command("stty", "size")
	cmd.Stdin = os.Stdin
	out, err := cmd.Output()
	str := string(out)
	if err != nil {
		log.Fatal(err)
	}
	l := 0
	for i, v := range str {
		if v == ' ' {
			l, _ = strconv.Atoi(str[i+1 : len(str)-1])
			break
		}
	}

	return l
}

func Filing(fileOutputName string, text string) {
	err := ioutil.WriteFile(fileOutputName, []byte(text), 0o644)
	if err != nil {
		log.Fatal(err)
	}
}
