package main

import (
	"fmt"
	"os"
	"strings"
	"syscall"
	"unsafe"
)

type winsize struct {
	Row    uint16
	Col    uint16
	Xpixel uint16
	Ypixel uint16
}

func main() {
	args := os.Args[1:]
	if len(args) != 1 || args[0] == "" {
		return
	}
	if isAllNewLine(args[0]) {
		return
	}
	input := strings.Split(args[0], "\\n")
	if NonAsciiCheck(input) {
		return
	}

	sint := make([][]int, len(input))
	for i := 0; i < len(input); i++ {
		sint[i] = make([]int, 0)
	}
	for i := 0; i < len(input); i++ {
		for j := 0; j < len(input[i]); j++ {
			sint[i] = append(sint[i], int(input[i][j]-' '))
		}
	}

	template, err := os.ReadFile("standard.txt")
	if err != nil {
		fmt.Println(err)
		return
	}
	dict := strings.Split(string(template), "\n")
	indexes := CountIndexes(dict)
	if len(template) != 6623 {
		fmt.Println("ERROR: Corrupted file.")
		return
	}

	for i := range input {
		if !validSize(dict, sint[i], indexes) {
			return
		}
	}
	for i := range input {
		if len(sint[i]) == 0 {
			fmt.Println()
			continue
		}
		banner := CreateBanner(dict, sint[i], indexes)
		PrintBanner(banner)
	}
}

func NonAsciiCheck(input []string) bool {
	for _, v := range input {
		for _, b := range v {
			if !(32 <= b && b <= 126) {
				fmt.Println("ERROR: Exeptional characters!")
				return true
			}
		}
	}
	return false
}

func LineisNewline(s string) bool {
	for _, v := range s {
		if v != '\n' {
			return false
		}
	}
	return true
}

func isAllNewLine(input string) bool {
	isAllNewLine := true
	for i := 0; i < len(input)-1; i += 2 {
		if !(input[i] == '\\' && input[i+1] == 'n') {
			isAllNewLine = false
		}
	}
	if isAllNewLine {
		for i := 0; i < len(input)-1; i += 2 {
			fmt.Println()
		}
	}
	return isAllNewLine
}

func CountIndexes(a []string) []int {
	var indexes []int
	j := 0
	for i := range a {
		// fmt.Println(i, a[i], LineisNewline(a[i]))
		if LineisNewline(a[i]) {
			if i != len(a)-1 {
				indexes = append(indexes, i)
				j++
			}
		}
	}
	return indexes
}

func PrintBanner(banner [8]string) {
	for _, v := range banner {
		fmt.Print(v)
	}
}

func CreateBanner(dict []string, sint []int, indexes []int) [8]string {
	var output [8]string
	for i := 0; i < len(output); i++ {
		output[i] = ""
		for _, v := range sint {
			output[i] += dict[i+indexes[v]+1]
		}
		output[i] += "\n"
	}
	return output
	// for i := 0; i < len(output); i++ {
	// 	fmt.Print(output[i])
	// }
}

func validSize(dict []string, sint []int, indexes []int) bool {
	l := indexes[1] - indexes[0]
	outputLenght := 0
	for i := 0; i < l; i++ {
		for _, v := range sint {
			outputLenght += len(dict[i+indexes[v]])
		}
	}
	outputLenght /= 8
	if outputLenght > int(getWidth()) {
		fmt.Println("ERROR: Input string is too long for current size of terminal...")
		return false
	}
	return true
}

func getWidth() uint {
	ws := &winsize{}
	retCode, _, errno := syscall.Syscall(syscall.SYS_IOCTL,
		uintptr(syscall.Stdin),
		uintptr(syscall.TIOCGWINSZ),
		uintptr(unsafe.Pointer(ws)))

	if int(retCode) == -1 {
		panic(errno)
	}
	return uint(ws.Col)
}
