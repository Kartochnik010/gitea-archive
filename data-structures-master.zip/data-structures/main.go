package main

import (
	"encoding/json"
	"fmt"
	"log"
)

func testHeap() {
	m := &MaxHeap{}
	buildHeap := []int{10, 20, 34, 12, 24, 75, 34, 76}

	for _, v := range buildHeap {
		m.Insert(v)
		fmt.Println(*m)
	}
	for v := range buildHeap {
		m.Extract()
		v++
		fmt.Println(*m)
	}
}

func testLinkedList() {
	m := &linkedList{}
	node1 := &node{data: 1}
	node2 := &node{data: 2}
	node3 := &node{data: 3}
	m.prepend(node1)
	m.prepend(node2)
	m.prepend(node3)
	fmt.Println(m.head.data, m.head.next.data, m.head.next.next.data)
}

type point struct {
	X int `json:"x"`
	Y int `json:"y"`
}

type figure struct {
	Color  string  `json:"color"`
	Points []point `json:"points"`
}

func init() {
	// testHeap()
	// testLinkedList()
}

func main() {
	map1 := make(map[string]figure, 0)
	map1["square"] = figure{
		Color: "red",
		Points: []point{
			{
				X: 1,
				Y: 1,
			},
			{
				X: 1,
				Y: 2,
			},
			{
				X: 1,
				Y: 2,
			},
			{
				X: 2,
				Y: 2,
			},
		},
	}
	json1, err := json.Marshal(map1)
	if err != nil {
		log.Fatal(err)
	}
	fmt.Printf("map1: %v\n", map1)
	for k := range map1 {
		fmt.Printf("%v \n", k)
	}
	// fmt.Printf("map1: %v\n", map1)
	fmt.Printf("json1: %s\n", json1)
}
