## Usage
To test the program, you need to follow the steps below:
1. Give permission to execute the files: in terminal enter `chmod +x *`
2. Download the [files](https://assets.01-edu.org/guess-the-number.zip) and extract the contents into the root folder `guess-it-1`
3. Follow the instructions in `README` of the extracted files

There are three algorithms: **`mode`**, **`cheat`**, **`default`** which can be switched in the shell script `student\script.sh`:  
   ```
   go run ./student/main.go mode
   ```

## Explanation of algorithms
### Default
By default, the algorithm takes the standard deviation of the preceding sample, multiplies to the coeffiecient and adds/subtracts it from the mean of the sample
```
left = Mean - StdDev * K
right = Mean + Stdev * K
```

To avoid the outliers disrupting the mean and the standard deviation, the constraints are provided. The algorithm excludes the outliers by the following check:   
`number > Mean - StrDev * k && number < Mean + StrDev * k`

The coeffiecient `K` have been calculated by analyzing the randomly generated dataset:
From the two graphs which show correlation between the coeffiecient and the points, it is clear that the best one is around `1.6`   
![](images/image1.png) ![](images/image3.png)   
Looking at the graphs closer, it can be derived that the best coeffiecient is `1.598`  
![](images/image2.png) ![](images/image4.png)

### Mode
By mode, the algorithm takes the frequent number of the collected sample. Thus, to the end it will try to guess the mode of the population.  

### Cheat
By cheat, the algorithm takes the frequent number of the dataset given. The modes have been calculated beforehand, that's why it's cheating. The first (in some datasets first two) number gives the hint what is the mode of the dataset.
This so-called algorithm beats notoriuous `Nic` AI bot all the time.