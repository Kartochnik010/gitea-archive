package mode

import (
	"bufio"
	"fmt"
	"strconv"
)

type modAlgo struct {
	collection map[int]int
	mode       int
}

func StartModeAlgo() modAlgo {
	var m modAlgo
	m.collection = map[int]int{}
	return m
}

func (m *modAlgo) Predict(scanner *bufio.Scanner) error {
	for scanner.Scan() {
		nbr, err := strconv.Atoi(scanner.Text())
		if err != nil {
			return err
		}
		m.collection[nbr] += 1
		m.calcMode()
		fmt.Printf("%d %d\n", m.mode, m.mode)
	}
	return nil
}

func (m *modAlgo) calcMode() {
	max := m.collection[m.mode]
	for nbr, freq := range m.collection {
		if freq > max {
			m.mode = nbr
		}
	}
}
