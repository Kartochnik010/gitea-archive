#!/bin/sh
# We assume that we are on the root folder, so we have to enter the
# student folder in order to run the `solution.js` file
go run ./student/main.go #mode #cheat