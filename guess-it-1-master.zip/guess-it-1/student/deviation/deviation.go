package deviation

import (
	"bufio"
	"fmt"
	"math"
	"strconv"
)

type algorithm struct {
	data   []int
	mean   float64
	strdev float64
	left   int
	right  int
	length float64
	k      float64 // coefficient to find range
	o      float64 // coefficient to exclude outliers
}

func StartAlgo() algorithm {
	var a algorithm
	a.k, a.o = 1.598, 2.075
	return a
}

func (a *algorithm) Predict(scanner *bufio.Scanner) error {
	for scanner.Scan() {
		nbr, err := strconv.Atoi(scanner.Text())
		if err != nil {
			return err
		}
		// collect the first 10 elements to identify outliers later
		if len(a.data) <= 10 {
			a.updateData(nbr)
			a.calcRange()
			fmt.Printf("%d %d\n", a.left, a.right)
			continue
		}
		// exlcude outliers
		if a.isInlier(nbr) {
			a.updateData(nbr)
			a.calcRange()
		}
		fmt.Printf("%d %d\n", a.left, a.right)
	}
	return nil
}

func (a *algorithm) calcMean() {
	var total float64
	for _, nbr := range a.data {
		total += float64(nbr)
	}
	a.mean = total / a.length
}

func (a *algorithm) calcStdDev() {
	var variance float64
	a.calcMean()
	for _, nbr := range a.data {
		variance += math.Pow((float64(nbr) - a.mean), 2)
	}
	if a.length > 1 {
		a.length--
	}
	a.strdev = math.Sqrt(variance / a.length)
}

func (a *algorithm) calcRange() {
	a.calcStdDev()
	a.left = int(math.Round(a.mean - (a.strdev * a.k)))
	a.right = int(math.Round(a.mean + (a.strdev * a.k)))
}

func (a *algorithm) isInlier(nbr int) bool {
	return nbr <= int(a.mean+a.strdev*a.o) && nbr >= int(a.mean-a.strdev*a.o)
}

func (a *algorithm) updateData(nbr int) {
	a.data = append(a.data, nbr)
	a.length = float64(len(a.data))
}
