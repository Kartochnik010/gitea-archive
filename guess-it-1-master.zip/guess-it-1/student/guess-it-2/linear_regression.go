package linear_regression

import (
	"bufio"
	"fmt"
	"strconv"
)

type regression struct {
	xTotal, yTotal, xyTotal, xxTotal, yyTotal float64
	a, b                                      float64
	length                                    float64
}

func StartRegression() regression {
	return regression{}
}

func (l *regression) Predict(scanner *bufio.Scanner) error {
	x := 0.0
	var left, right int
	for scanner.Scan() {
		nbr, err := strconv.Atoi(scanner.Text())
		y := float64(nbr)
		if err != nil {
			return err
		}
		if x == 0 {
			left = nbr - 46
			right = nbr + 46
			fmt.Printf("%d %d\n", left, right)
			l.updateTotals(x, y)
			l.updateLength()
			x++
			continue
		}
		if nbr < left-200 || nbr > right+200 {
			fmt.Printf("%d %d\n", left, right)
			x++
			continue
		}
		l.updateTotals(x, y)
		l.updateLength()
		l.calcEquation()
		next := ((x + 1) * l.b) + l.a
		left, right := int(next)-46, int(next)+46
		fmt.Printf("%d %d\n", left, right)
		x++
	}
	return nil
}

func (l *regression) calcEquation() {
	l.a = ((l.yTotal * l.xxTotal) - (l.xTotal)*(l.xyTotal)) / ((l.length * l.xxTotal) - (l.xTotal * l.xTotal))
	l.b = ((l.length * l.xyTotal) - (l.xTotal * l.yTotal)) / ((l.length * l.xxTotal) - (l.xTotal * l.xTotal))
}

func (l *regression) updateTotals(x, y float64) {
	l.xTotal = l.xTotal + x
	l.yTotal = l.yTotal + y
	l.xyTotal = l.xyTotal + (x * y)
	l.xxTotal = l.xxTotal + (x * x)
	l.yyTotal = l.yyTotal + (y * y)
}

func (l *regression) updateLength() {
	l.length += 1
}

// #TODO outliers, meansquarederror
