package main

import (
	"bufio"
	"fmt"
	"guess-it-1/student/cheating"
	"guess-it-1/student/deviation"
	linear_regression "guess-it-1/student/guess-it-2"
	"guess-it-1/student/mode"
	"os"
)

func main() {
	scanner := bufio.NewScanner(os.Stdin)
	algo := "linear"
	if len(os.Args) == 2 {
		algo = os.Args[1]
	}
	var err error
	switch algo {
	case "cheat":
		c := cheating.StartCheating()
		err = c.Cheat(scanner)
	case "mode":
		m := mode.StartModeAlgo()
		err = m.Predict(scanner)
	case "linear":
		l := linear_regression.StartRegression()
		err = l.Predict(scanner)
	default:
		a := deviation.StartAlgo()
		err = a.Predict(scanner)

	}
	if err != nil {
		fmt.Println(err)
	}
}
