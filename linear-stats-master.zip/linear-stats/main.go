package main

import (
	"fmt"
	"io/ioutil"
	"math"
	"os"
	"strconv"
	"strings"
)

func main() {
	if len(os.Args) != 2 {
		fmt.Println("Usage: go run your-program.go data.txt")
		return
	}

	content, err := ioutil.ReadFile(os.Args[1])
	if err != nil {
		fmt.Println("Usage: go run your-program.go data.txt")
		return
	}
	slice := strings.Split(string(content), "\n")
	var arrX, arrY []float64
	for i, key := range slice {
		num, err := strconv.Atoi(key)
		if err == nil {
			arrX = append(arrX, float64(i))
			arrY = append(arrY, float64(num))
		}
	}
	Result(arrX, arrY)
}

func Result(arrX, arrY []float64) {
	// Linear Regression line
	N := float64(len(arrX))
	var (
		sumX    float64 // sum of x array
		sumY    float64 // sum of y array
		sumXof2 float64 // sum of x array of power 2
		sumXY   float64 // sum of x*y
		sumXX   float64 // sum of x-x0 of power 2
		sumYY   float64 // sum of y-y0 of power 2
		sumXXYY float64 // sum of (x-x0)*(y-y0)
	)

	for i := range arrX {
		sumX += arrX[i]
		sumY += arrY[i]
		sumXof2 += arrX[i] * arrX[i]
		sumXY += arrX[i] * arrY[i]
	}
	b := (sumY*sumXof2 - sumXY*sumX) / (N*sumXof2 - sumX*sumX)
	a := (N*sumXY - sumX*sumY) / (N*sumXof2 - sumX*sumX)
	fmt.Printf("Linear Regression Line: y = %0.6fx + %0.6f\n", a, b)

	for i := 0; i < len(arrX); i++ {
		sumXX += (arrX[i] - sumX/N) * (arrX[i] - sumX/N)
		sumYY += (arrY[i] - sumY/N) * (arrY[i] - sumY/N)
		sumXXYY += (arrX[i] - sumX/N) * (arrY[i] - sumY/N)
	}
	// Pearson Correlation Coefficien
	r := sumXXYY / (math.Sqrt(sumXX * sumYY))

	fmt.Printf("Pearson Correlation Coefficient: %0.10f\n", r)
}
