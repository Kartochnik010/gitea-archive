# ascii-art-web 
Includes stylize and export-file




Authors: Kartochnik010, recyclebin

## Usage 
Download and unzip repository file. Enter main package. Open console and run: 
```
 $ go run cmd/main.go
```
