package main

import (
	"fmt"
	//	"io/ioutil"
	"math"
	"os"
	"strconv"
	"strings"
)

func main() {
	// read args & check for agrs' number

	if len(os.Args) != 2 {
		fmt.Println("Wrong number of arguments")
		return
	}

	file1 := os.Args[1]

	// checking for empty file

	fileInfo, err := os.Stat(file1)
	if err != nil {
		fmt.Println("Error occured")
		fmt.Println(err)
		return
	} else if fileInfo.Size() == 0 {
		fmt.Println("The file is empty")
		return
	}

	// check for file errors like exist or not

	data, err := os.ReadFile(file1)
	if err != nil {
		fmt.Println("Error occurred")
		fmt.Println(err)
		return
	}

	InitialText := strings.Fields(string(data)) // splitting data string into slice of substrings splitted by white spaces

	var floatData []float64

	// checking if substrings are numbers, if so appending them to floatData slice as float

	for i := 0; i < len(InitialText); i++ {
		numb, err := strconv.Atoi(InitialText[i])
		if err == nil {
			floatData = append(floatData, float64(numb))
		} else {
			fmt.Println("Error occured")
			fmt.Println("Possibly wrong data type in the file")
			return
		}
	}

	// outputing the results via specified funcs

	PrintAverage(floatData)
	PrintMedian(floatData)
	PrintVariance(floatData)
	PrintStandardDeviation(floatData)
}

func PrintAverage(numbers []float64) {
	fmt.Printf("Average: %d\n", int(math.Round(Average(numbers))))
}

func PrintMedian(numbers []float64) {
	fmt.Printf("Median: %d\n", int(math.Round(Median(numbers))))
}

func PrintVariance(numbers []float64) {
	fmt.Printf("Variance: %d\n", int(math.Round(Variance(numbers))))
}

func PrintStandardDeviation(numbers []float64) {
	variance := Variance(numbers)

	fmt.Printf("Standard Deviation: %d\n", int(math.Round(math.Sqrt(variance))))
}

func Average(numbers []float64) float64 {
	var sum float64
	length := len(numbers)
	for i := 0; i < length; i++ {
		sum += numbers[i]
	}
	average := sum / float64(length)
	return average
}

func Median(numbers []float64) float64 {
	length := len(numbers)

	for i := 0; i < length; i++ {
		for k := 0; k < length-i-1; k++ {
			if numbers[k] > numbers[k+1] {
				tmp := numbers[k]
				numbers[k] = numbers[k+1]
				numbers[k+1] = tmp
			}
		}
	}

	if length%2 == 0 {
		return (numbers[length/2] + numbers[length/2-1]) / float64(2)
	} else {
		return numbers[length/2]
	}
}

func Variance(numbers []float64) float64 {
	var temp float64
	var tempSum float64
	var eachDeviation []float64

	length := len(numbers)

	average := Average(numbers)

	for i := 0; i < length; i++ {
		temp = average - numbers[i]
		eachDeviation = append(eachDeviation, temp*temp)
	}

	for i := 0; i < length; i++ {
		tempSum += eachDeviation[i]
	}

	return tempSum / float64(length)
}
