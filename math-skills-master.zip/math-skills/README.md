The purpose of this project is for you to calculate the following:
    Average
    Median
    Variance
    Standard Deviation

The file is located in https://01.alem.school/git/janbotik/math-skills?event=531 under main.go

How to run the program:  Run the command in the terminal "go run main.go data.txt"

The "data.txt" file should have data represented as a graph in which the values of the x axis are the number of the lines (0, 1, 2, 3, 4, 5 ...) and the values of the y axis are the actual numbers (189, 113, 121, 114, 145, 110...).