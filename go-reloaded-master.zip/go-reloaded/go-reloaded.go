package main

import (
	"fmt"
	"os"
	"strconv"
	"strings"
)

func main() {
	args := os.Args[1:]
	if len(args) == 2 {
		fileName := args[0]
		resultFileName := args[1]
		file, err := os.ReadFile(fileName)
		if err != nil {
			fmt.Println(err)
			return
		}
		if len(string(file)) == 0 {
			fmt.Println("File cannot be empty")
			return
		}
		formattedString := tickleBits(formatString(strings.Join(strings.Split(string(file), "\n"), " ")))
		resultFile, _ := os.Create(resultFileName)
		resultFile.WriteString(formattedString)

		test(fileName, resultFileName)
	} else {
		fmt.Println("Please, Enter only two arguments. (First, the name of the read file, and second, the name of the created or edited file.)")
	}
}

func tickleBits(text string) string {
	words := strings.Split(text, " ")
	iL := 0
	iR := 0

kiki:
	for i := 0; i < len(words); i++ {
		if words[i] == "'" || string(words[i][0]) == "'" || string(words[i][len(words[i])-1]) == "'" {
			iL = i
			for j := i + 1; j < len(words); j++ {
				if words[j] == "'" || words[j][len(words[j])-1] == '\'' || words[j][0] == '\'' {
					iR = j
					break kiki
				}
			}
		}
	}
	if iL != 0 {
		words[iL+1] = words[iL] + words[iL+1]
		words = append(words[:iL], words[iL+1:]...)
	}
	if iR != 0 {
		words[iR-2] = words[iR-2] + words[iR-1]
		words = append(words[:iR-1], words[iR+1-1:]...)
	}

	return strings.Join(words, " ")
}

func formatString(text string) string {
	words := strings.Split(text, " ")
	for i := 0; i < 100; i++ {
	kiwi:
		for i := 0; i < len(words); i++ {
			for len(words[i]) == 0 {
				if len(words) != i {
					words = append(words[:i], words[i+1:]...)
					break kiwi
				} else {
					words = append(words[:i-1], words[i+1-1:]...)
				}
			}
			// fmt.Println(words[i], len(words[i]), i)
		}
	}

	for heh := 0; heh < 100; heh++ {
		for i := 0; i < len(words); i++ {
			v := words[i]
			if words[0] == "(hex)" || words[0] == "(bin)" || words[0] == "(up)" || words[0] == "(low)" || words[0] == "(cap)" {
				words = words[1:]
				continue
			}
			if words[0] == "(up," || words[0] == "(low," || words[0] == "(cap," {
				words = words[2:]
				continue
			}
			if v == "(hex)" || v == "(HEX)" || v == "(Hex)" {
				a, _ := strconv.ParseInt(words[i-1], 16, 64)
				words[i-1] = fmt.Sprint(a)
				words = append(words[:i], words[i+1:]...)
			}
			if v == "(bin)" || v == "(BIN)" || v == "(Bin)" {
				a, _ := strconv.ParseInt(words[i-1], 2, 64)
				words[i-1] = fmt.Sprint(a)
				words = append(words[:i], words[i+1:]...)
			}

			if v == "(up)" || v == "(Up)" || v == "(UP)" {
				words[i-1] = strings.ToTitle(words[i-1])
				words = append(words[:i], words[i+1:]...)
			}
			if v == "(up," || v == "(Up," || v == "(UP," {
				n, _ := strconv.Atoi(string(words[i+1][:len(words[i+1])-1]))
				if len(words[:i]) < n {
					fmt.Println("WARNING!!! You want to change more words that there is, dumbass")
					n = len(words[:i])
				}
				for j := 1; j <= n; j++ {
					words[i-j] = strings.ToTitle(words[i-j])
				}
				words = append(words[:i], words[i+2:]...)
			}

			if v == "(low)" || v == "(Low)" || v == "(LOW)" {
				words[i-1] = strings.ToLower(words[i-1])
				words = append(words[:i], words[i+1:]...)
			}
			if v == "(low," || v == "(Low," || v == "(LOW," {
				n, _ := strconv.Atoi(string(words[i+1][:len(words[i+1])-1]))
				if len(words[:i]) < n {
					fmt.Println("WARNING!!! You want to change more words that there is, dumbass")
					n = len(words[:i])
				}
				for j := 1; j <= n; j++ {
					words[i-j] = strings.ToLower(words[i-j])
				}

				words = append(words[:i], words[i+2:]...)
			}

			if v == "(cap)" || v == "(Cap)" || v == "(CAP)" {
				words[i-1] = strings.Title(words[i-1])
				words = append(words[:i], words[i+1:]...)
			}
			if v == "(cap," || v == "(Cap," || v == "(CA{}," {
				n, _ := strconv.Atoi(string(words[i+1][:len(words[i+1])-1]))
				if len(words[:i]) < n {
					fmt.Println("WARNING!!! You want to change more words that there is, dumbass")
					n = len(words[:i])
				}
				for j := 1; j <= n; j++ {
					words[i-j] = strings.Title(words[i-j])
				}
				words = append(words[:i], words[i+2:]...)
			}

			if len(words) != i {
				if words[i] == "a" && len(words) > 1 {
					if words[i+1][0] == 'h' || words[i+1][0] == 'a' || words[i+1][0] == 'e' || words[i+1][0] == 'i' || words[i+1][0] == 'o' || words[i+1][0] == 'u' {
						words[i] += "n"
					}
				}

				if len(words[i]) != 0 && i != 0 {
					if v[0] == ',' || v[0] == '.' || v == "!" || v == "?" {
						words[i] = words[i][1:]
						words[i-1] += string(v[0])
					}
				}
			}

			if i == 0 && (v == "." || v == "," || v == ".." || v == "!" || v == "!!" || v == "!!!" || v == "??" || v == "???" || v == "?" || v == "!?" || v == "..." || v == ":" || v == ";") {
				words = (words[1:])
			}

			if (v == "," || v == "." || v == ".." || v == "!" || v == "!!" || v == "!!!" || v == "??" || v == "???" || v == "?" || v == "!?" || v == "..." || v == ":" || v == ";") && i != len(words)-1 && i != 0 {
				// fmt.Println(v, i, len(words), words)

				words[i-1] += words[i]
				words = append(words[:i], words[i+1:]...)

			}

			// at the end of the string
			if (v == "," || v == "!" || v == "?" || v == "!?" || v == "..." || v == ":" || v == ";" || v == "." || v == "..") && i == len(words)-1 {
				// fmt.Println(v, i, len(words), words)
				words[i-1] = words[i-1] + words[i]
				words = append(words[:i], words[i+1:]...)

			}

		}
	}

	return strings.Join(words, " ")
}

func test(fileName string, resultFileName string) {
	file, _ := os.ReadFile(fileName)
	resultFile, _ := os.ReadFile(resultFileName)
	fmt.Println(string(file))
	fmt.Println(string(resultFile))
}
