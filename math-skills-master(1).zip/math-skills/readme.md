## How to audit

##### Firstly download the ``` math-skills.exe ``` file presented on the audit page and then run it. Every time it will generate new ``` data.txt ``` file that need to be put to the test.

###### ``` math-skills.exe ``` will also print the right answer in console
