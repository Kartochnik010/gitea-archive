package main

import (
	"fmt"
	"math"
	"os"
	"strconv"
	"strings"
)

func main() {
	args := os.Args[1:]
	if len(args) == 0 {
		fmt.Println("Invalid number of arguments")
		return
	}
	file, err := os.ReadFile(args[0])
	if err != nil {
		fmt.Println(err)
		return
	}
	s := strings.Split(string(file), "\n")
	if len(s) == 1 || len(s) == 0 && s[0] == "" {
		fmt.Println("File cannot be empty")
		return
	}
	nums := make([]float64, len(s)-1)

	for i := 0; i < len(s)-1; i++ {
		v, _ := strconv.Atoi(s[i])
		nums[i] = float64(v)
	}
	for i := 0; i < len(nums)-1; i++ {
		for j := 0; j < len(nums)-i-1; j++ {
			if nums[j] > nums[j+1] {
				nums[j], nums[j+1] = nums[j+1], nums[j]
			}
		}
	}

	// fmt.Println("Current data set:", nums)
	fmt.Println("Average:", Average(nums))
	fmt.Println("Median:", Median(nums))
	fmt.Println("Variance:", Variance(nums))
	fmt.Println("Standard Deviation:", Deviation(nums))
	// fmt.Printf("\n")
	// fmt.Println("Useful links to check the answers:")
	// fmt.Println("Average: https://www.calculator.net/average-calculator.html?numberinputs=189%2C+113%2C+121%2C+114%2C+145%2C+110&x=104&y=25")
	// fmt.Println("Median: https://www.calculatorsoup.com/calculators/statistics/mean-median-mode.php")
	// fmt.Println("Variance: https://www.calculatorsoup.com/calculators/statistics/variance-calculator.php")
	// fmt.Println(" Deviation: https://www.calculator.net/standard-deviation-calculator.html?numberinputs=189%2C+113%2C+121+%2C114%2C+145%2C+110&ctype=p&x=29&y=8")
}

func Average(nums []float64) int {
	res := 0.0
	for i := 0; i < len(nums); i++ {
		res += nums[i]
	}
	res /= float64(len(nums))
	if res-float64(int(res)) >= 0.5 {
		return int(res) + 1
	}
	return int(res)
}

func Median(nums []float64) int {
	res := 0.0
	if len(nums)%2 == 1 {
		res = nums[len(nums)/2]
	} else {
		res = (nums[(len(nums)/2)-1] + nums[(len(nums)/2)]) / 2
	}
	if res-float64(int(res)) >= 0.5 {
		return int(res) + 1
	}
	return int(res)
}

func Variance(nums []float64) int {
	x1 := 0.0
	for i := 0; i < len(nums); i++ {
		x1 += nums[i]
	}
	x1 /= float64(len(nums))

	x2 := make([]float64, len(nums))
	res := 0.0
	for i := 0; i < len(nums); i++ {
		x2[i] = (nums[i] - x1) * (nums[i] - x1)
		res += x2[i]
	}
	res /= float64(len(nums))
	if res-float64(int(res)) >= 0.5 {
		return int(res) + 1
	}
	return int(res)
}

func Deviation(nums []float64) int {
	x1 := 0.0
	for i := 0; i < len(nums); i++ {
		x1 += nums[i]
	}
	x1 /= float64(len(nums))

	x2 := make([]float64, len(nums))
	res := 0.0
	for i := 0; i < len(nums); i++ {
		x2[i] = (nums[i] - x1) * (nums[i] - x1)
		res += x2[i]
	}
	res = math.Sqrt(res / float64(len(nums)))
	if res-float64(int(res)) >= 0.5 {
		return int(res) + 1
	}
	return int(res)
}
